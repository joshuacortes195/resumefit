async function getConnection() {
  const { connection } = await chrome.storage.local.get("connection");
  return connection ?? null;
}
const key = (tabId) => `apply:${tabId}`;
async function setPending(tabId, pending) {
  await chrome.storage.session.set({ [key(tabId)]: pending });
}
async function clearPending(tabId) {
  await chrome.storage.session.remove(key(tabId));
}
chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.contextMenus.create({ id: "resumefit-scan-selection", title: "Scan this job description with ResumeFit", contexts: ["selection"] });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "resumefit-scan-selection" || !info.selectionText || !tab?.id) return;
  void chrome.storage.session.set({ pendingScan: { text: info.selectionText, url: tab.url ?? "", title: tab.title ?? "" } });
  void chrome.sidePanel.open({ tabId: tab.id });
});
chrome.runtime.onMessageExternal.addListener((message, sender, respond) => {
  const origin = sender.url ? new URL(sender.url).origin : "";
  if (message.type === "resumefit-connect" && message.token && message.apiBase === origin) {
    const offer = { apiBase: origin, token: message.token };
    void chrome.storage.session.set({ connectionOffer: offer }).then(() => respond({ ok: true }));
    if (sender.tab?.id) void chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => void 0);
    return true;
  }
  if (message.type === "resumefit-apply" && typeof message.url === "string") {
    const url = message.url;
    void getConnection().then(async (connection) => {
      if (connection?.apiBase !== origin || !/^https:\/\//.test(url)) return respond({ ok: false });
      const tab = await chrome.tabs.create({ url, active: true, windowId: sender.tab?.windowId, index: sender.tab ? sender.tab.index + 1 : void 0 });
      if (!tab.id) return respond({ ok: false });
      await setPending(tab.id, { jobId: typeof message.jobId === "string" ? message.jobId : null, resumeId: typeof message.resumeId === "string" ? message.resumeId : null });
      void chrome.sidePanel.open({ tabId: tab.id }).catch(() => void 0);
      respond({ ok: true });
    });
    return true;
  }
  if (message.type === "resumefit-ping") respond({ ok: true, version: chrome.runtime.getManifest().version, autoApply: true });
  return false;
});
chrome.tabs.onRemoved.addListener((tabId) => void clearPending(tabId));
