async function getConnection() {
  const { connection } = await chrome.storage.local.get("connection");
  return connection ?? null;
}
class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
  status;
}
async function call(path, body) {
  const connection = await getConnection();
  if (!connection) throw new ApiError("Connect the extension to your ResumeFit account first.", 401);
  let response;
  try {
    response = await fetch(`${connection.apiBase}/api/ext/${path}`, {
      method: body === void 0 ? "GET" : "POST",
      headers: { Authorization: `Bearer ${connection.token}`, ...body === void 0 ? {} : { "Content-Type": "application/json" } },
      body: body === void 0 ? void 0 : JSON.stringify(body)
    });
  } catch {
    throw new ApiError("Could not reach ResumeFit. Check your connection and try again.", 0);
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(data.error ?? "Something went wrong. Try again.", response.status);
  return data;
}
const api = {
  me: () => call("me"),
  saveJob: (job) => call("jobs", job),
  scan: (input) => call("scan", input),
  importLinkedin: (profile) => call("linkedin", profile),
  // one of the person's own resumes as a file, to attach to an application
  resumeFile: (id) => call(`resumes/${encodeURIComponent(id)}/file`),
  // the cover letter saved on a tracker card, as a pdf
  coverLetterFile: (jobId) => call(`cover-letter?jobId=${encodeURIComponent(jobId)}`),
  // an answer to a written question: the person's saved one when it fits, otherwise a draft to check
  answer: (input) => call("answer", input),
  // only an answer the person gave before, for this job or saved for every job. null when there is none, and nothing is drafted
  savedAnswer: (input) => call("answer", { ...input, jdText: "", savedOnly: true }),
  // tells the web app how a fill went, so it shows on the tracker and on the Auto Apply page
  reportApplication: (report) => call("applications", report)
};
const key = (tabId) => `apply:${tabId}`;
async function setPending(tabId, pending) {
  await chrome.storage.session.set({ [key(tabId)]: pending });
}
async function clearPending(tabId) {
  await chrome.storage.session.remove(key(tabId));
}
function profileValues(account) {
  const { profile, current = { title: null, company: null } } = account;
  if (!profile) return {};
  const [first = "", ...rest] = (profile.fullName ?? "").trim().split(/\s+/);
  const yesNo = (value) => value === null ? "" : value ? "Yes" : "No";
  const salary = profile.desiredSalaryMin ?? profile.desiredSalaryMax;
  const hispanic = profile.eeoHispanic ?? "Decline to self-identify";
  const values = {
    firstName: first,
    preferredName: profile.preferredName || first,
    pronouns: profile.pronouns ?? "",
    address: profile.streetAddress ?? "",
    over18: yesNo(profile.over18 ?? null),
    howHeard: profile.howHeard ?? "",
    school: profile.school ?? "",
    degree: profile.degree ?? "",
    major: profile.major ?? "",
    graduationYear: profile.graduationYear ?? "",
    // the month and the year together when both are known, otherwise just the year
    graduationDate: [profile.graduationMonth, profile.graduationYear].filter(Boolean).join(" "),
    // a gpa the person asked us to keep to ourselves is never typed in
    gpa: profile.gpaNeverFill ? "" : profile.gpa ?? "",
    lastName: rest.join(" "),
    fullName: profile.fullName ?? "",
    email: profile.email ?? "",
    phone: profile.phone ?? "",
    linkedin: profile.linkedinUrl ?? "",
    github: profile.githubUrl ?? "",
    website: profile.portfolioUrl ?? "",
    city: profile.city ?? "",
    state: profile.state ?? "",
    country: profile.country ?? "",
    zip: profile.zip ?? "",
    location: [profile.city, profile.state].filter(Boolean).join(", "),
    currentCompany: current.company ?? "",
    currentTitle: current.title ?? "",
    yearsExperience: profile.yearsExperience === null ? "" : String(profile.yearsExperience),
    salary: salary === null ? "" : String(salary),
    startDate: profile.earliestStartDate ?? profile.noticePeriod ?? "",
    // only a clear yes or no is ever given for these
    workAuthorization: /not authorized/i.test(profile.workAuthorization ?? "") ? "No" : profile.workAuthorization ? "Yes" : "",
    sponsorship: yesNo(profile.needsSponsorship),
    relocation: yesNo(profile.willingToRelocate),
    // demographic answers come straight from what the person chose, which starts on decline
    eeoGender: profile.eeoGender,
    // someone who chose Hispanic or Latino as their race has already answered this one
    eeoHispanic: /decline/i.test(hispanic) && profile.eeoRace === "Hispanic or Latino" ? "Yes" : hispanic,
    eeoRace: profile.eeoRace,
    eeoVeteran: profile.eeoVeteran,
    eeoDisability: profile.eeoDisability
  };
  for (const key2 of Object.keys(values)) if (!values[key2]) delete values[key2];
  return values;
}
const MAX_DRAFTS = 6;
const MAX_LOOKUPS = 12;
function worthDrafting(field) {
  return field.key === "question" && field.value.trim() === "" && field.label.trim().length >= 5 && (field.required || field.label.includes("?"));
}
function pickResume(account, jobId, wanted) {
  const linked = jobId ? account.resumes.find((resume) => resume.linkedJobId === jobId) : void 0;
  const asked = account.resumes.find((resume) => resume.id === wanted);
  return (linked ?? asked ?? account.resumes.find((resume) => resume.isBase) ?? account.resumes[0])?.id ?? null;
}
async function fillEverything(ask, account, options, source = api) {
  const resume = options.resumeId ? await source.resumeFile(options.resumeId).catch(() => null) : null;
  const coverLetter = options.coverLetter && options.jobId ? await source.coverLetterFile(options.jobId).catch(() => null) : null;
  const values = profileValues(account);
  let fields = await ask({ type: "autofill", values, resume, coverLetter, onlyNew: options.onlyNew });
  const swap = (next) => {
    if (next) fields = fields.map((field) => field.id === next.id ? next : field);
  };
  for (const question of fields.filter((field) => worthDrafting(field) && field.status !== "review" && field.fresh !== false).slice(0, MAX_DRAFTS)) {
    try {
      const result = await source.answer({ question: question.label.slice(0, 500), jdText: options.jdText, resumeId: options.resumeId ?? void 0, jobId: options.jobId ?? void 0 });
      swap(await ask({ type: "set-field", id: question.id, value: result.answer, status: result.source === "saved" ? "filled" : "review" }));
    } catch {
    }
  }
  const lookup = source.savedAnswer;
  if (lookup) {
    for (const empty of fields.filter((field) => field.status === "missing" && field.kind !== "file" && field.fresh !== false && field.label.trim().length > 1).slice(0, MAX_LOOKUPS)) {
      try {
        const { answer } = await lookup({ question: empty.label.slice(0, 500), jobId: options.jobId ?? void 0 });
        if (answer) swap(await ask({ type: "set-field", id: empty.id, value: answer, status: "filled", key: empty.key ?? void 0 }));
      } catch {
      }
    }
  }
  return { fields, resume, coverLetter };
}
function tally(fields) {
  return {
    filled: fields.filter((field) => field.status === "filled" || field.status === "review").length,
    needs: fields.filter((field) => field.status === "missing" || field.status === "review").length
  };
}
const SENDABLE = ["greenhouse", "lever", "ashby"];
const CONFIRM_SECONDS = 20;
const ABOUT_EMPLOYER = /\bwhy\b.{0,60}\b(us|here|join|our|this (company|role|position|team|job|opportunity)|work (at|for|with))\b|\bwhat (interests|excites|attracts|draws|appeals|motivates)\b|\b(our|this) (company|mission|products?|values|team|culture|role|position)\b|\babout (us|our)\b|\binterest(ed)? in (us|this|our|working|joining)\b/i;
const NAMES_A_PLACE = /\b(at|join|joining)\s+[A-Z][A-Za-z0-9&.'-]+/;
function aboutCompany(label, company = "") {
  const name = company.trim().toLowerCase();
  if (name.length > 2 && label.toLowerCase().includes(name)) return true;
  if (/^\s*[Ww]hy\s+[A-Z][\w&.'-]*(\s+[A-Z][\w&.'-]*)?\s*\??\s*$/.test(label)) return true;
  return ABOUT_EMPLOYER.test(label) || NAMES_A_PLACE.test(label.replace(/^\s*\S+/, ""));
}
function waitingOn(fields, account, company = "") {
  const mode = account.profile?.autoSend ?? "off";
  return fields.filter((field) => field.kind !== "file" && field.label.trim().length > 1 && (field.status === "missing" || mode !== "all" && field.status === "review" && field.key === "question" && aboutCompany(field.label, company))).map((field) => ({ label: field.label.slice(0, 300), written: field.kind === "text" || field.kind === "textarea", ...field.options?.length ? { options: field.options.slice(0, 40).map((option) => option.slice(0, 200)) } : {} })).slice(0, 40);
}
function stuckOn(page, account) {
  if ((account.profile?.autoSend ?? "off") === "off") return "Sending is switched off in your application profile.";
  if (page.fillBlocked) return "This site does not allow tools to send applications.";
  if (!page.ats || !SENDABLE.includes(page.ats.id)) return "We only send on Greenhouse, Lever and Ashby forms.";
  if (page.multiPage) return "This form has several pages.";
  if (page.captcha) return "The form has a captcha, which only you can do.";
  return null;
}
function whyNotSend(page, fields, account) {
  const mode = account.profile?.autoSend ?? "off";
  const stuck = stuckOn(page, account);
  if (stuck) return stuck;
  if ((account.sendsLeft ?? 0) <= 0) return "You have reached the number of applications you let us send in a day.";
  const empty = fields.filter((field) => field.status === "missing").length;
  if (empty > 0) return `${empty} required ${empty === 1 ? "answer is" : "answers are"} still empty.`;
  if (fields.some((field) => field.key === "resume" && field.status !== "filled")) return "Your resume could not be attached.";
  const theirs = fields.filter((field) => field.status === "review" && field.key === "question" && aboutCompany(field.label, page.job?.company)).length;
  if (mode === "safe" && theirs > 0) return `${theirs} ${theirs === 1 ? "question is" : "questions are"} about this company, and that answer should be yours.`;
  return null;
}
async function sendApplication(ask, pause2 = (ms) => new Promise((resolve) => setTimeout(resolve, ms)), seconds = CONFIRM_SECONDS) {
  const result = await ask({ type: "submit" });
  if (!result.pressed) return { sent: false, reason: result.reason };
  for (let second = 0; second < seconds; second++) {
    await pause2(1e3);
    const page = await ask({ type: "read-page" }).catch(() => null);
    if (page?.confirmed) return { sent: true };
    if (page?.captcha) return { sent: false, reason: "We pressed Submit and the site asked for a captcha, which only you can do. Finish it on the page." };
  }
  return { sent: false, reason: "We pressed Submit, but the page never said the application went through. Have a look at it." };
}
const FORM_WAIT_SECONDS = 8;
const answersOf = (fields) => fields.filter((field) => field.kind !== "file" && field.value).map(({ label, value, status }) => ({ label: label.slice(0, 300), value: value.slice(0, 3e3), status })).slice(0, 120);
async function runApplication(account, job, hooks) {
  const pause2 = hooks.pause ?? ((ms) => new Promise((resolve) => setTimeout(resolve, ms)));
  const look = async (patient) => {
    let seen = await hooks.ask({ type: "read-page" });
    for (let tries = 0; patient && tries < FORM_WAIT_SECONDS && !seen.hasForm && !seen.fillBlocked; tries++) {
      await pause2(1e3);
      seen = await hooks.ask({ type: "read-page" }).catch(() => seen);
    }
    return seen;
  };
  let page = await look(false);
  if (!page.hasForm && !page.fillBlocked) {
    const link = await hooks.ask({ type: "find-apply" });
    if (link) await hooks.goTo(link);
    page = await look(true);
  }
  if (page.fillBlocked) return { sent: false, reason: "This site does not allow tools to fill in applications.", filled: 0, needs: 0 };
  if (!page.hasForm) return { sent: false, reason: "We could not find the application form on this page.", filled: 0, needs: 0 };
  const resumeId = pickResume(account, job.jobId, job.resumeId);
  const base = { jobId: job.jobId, ats: page.ats?.name ?? null, applyUrl: page.url, resumeId, today: hooks.today };
  const result = await fillEverything(hooks.ask, account, { resumeId, jobId: job.jobId, jdText: page.job?.description ?? "", coverLetter: true }, hooks.source);
  const { filled, needs } = tally(result.fields);
  const coverLetter = result.coverLetter !== null && result.fields.some((field) => field.key === "coverLetter" && field.status === "filled");
  const filledIn = { ...base, fieldsFilled: filled, fieldsNeedingAttention: needs, answers: answersOf(result.fields), coverLetter };
  const now = await hooks.ask({ type: "read-page" }).catch(() => page);
  const after = { ...page, captcha: now.captcha };
  const stuck = stuckOn(after, account);
  await hooks.report({ ...filledIn, status: "needs_review", stuck, waiting: stuck ? [] : waitingOn(result.fields, account, page.job?.company) }).catch(() => void 0);
  const held = whyNotSend(after, result.fields, account);
  if (held) return { sent: false, reason: held, filled, needs };
  const send = await sendApplication(hooks.ask, hooks.pause);
  if (!send.sent) return { sent: false, reason: send.reason ?? "The form was not sent.", filled, needs };
  await hooks.report({ ...filledIn, status: "applied", fieldsNeedingAttention: 0, sentBy: "auto", waiting: [], stuck: null }).catch(() => void 0);
  return { sent: true, reason: null, filled, needs };
}
chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.contextMenus.create({ id: "resumefit-scan-selection", title: "Scan this job description with ResumeFit", contexts: ["selection"] });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "resumefit-scan-selection" || !info.selectionText || !tab?.id) return;
  void chrome.storage.session.set({ pendingScan: { text: info.selectionText, url: tab.url ?? "", title: tab.title ?? "" } });
  void chrome.sidePanel.open({ tabId: tab.id });
});
chrome.runtime.onMessageExternal.addListener((message, sender, respond) => {
  const origin = sender.url ? new URL(sender.url).origin : "";
  if (message.type === "resumefit-connect" && message.token && message.apiBase === origin) {
    const offer = { apiBase: origin, token: message.token };
    void chrome.storage.session.set({ connectionOffer: offer }).then(() => respond({ ok: true }));
    if (sender.tab?.id) void chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => void 0);
    return true;
  }
  if (message.type === "resumefit-apply" && typeof message.url === "string") {
    const url = message.url;
    void getConnection().then(async (connection) => {
      if (connection?.apiBase !== origin || !/^https:\/\//.test(url)) return respond({ ok: false });
      const job = { url, jobId: typeof message.jobId === "string" ? message.jobId : null, resumeId: typeof message.resumeId === "string" ? message.resumeId : null };
      if (await canRunAlone()) {
        await enqueue([job]);
        return respond({ ok: true, auto: true });
      }
      const tab = await chrome.tabs.create({ url, active: true, windowId: sender.tab?.windowId, index: sender.tab ? sender.tab.index + 1 : void 0 });
      if (!tab.id) return respond({ ok: false });
      await setPending(tab.id, { jobId: job.jobId, resumeId: job.resumeId });
      void chrome.sidePanel.open({ tabId: tab.id }).catch(() => void 0);
      respond({ ok: true, auto: false });
    });
    return true;
  }
  if (message.type === "resumefit-apply-many" && Array.isArray(message.jobs)) {
    const jobs = message.jobs.filter((job) => typeof job.url === "string" && /^https:\/\//.test(job.url)).map((job) => ({ url: job.url, jobId: typeof job.jobId === "string" ? job.jobId : null, resumeId: typeof job.resumeId === "string" ? job.resumeId : null })).slice(0, MAX_QUEUE);
    void getConnection().then(async (connection) => {
      if (connection?.apiBase !== origin || jobs.length === 0 || !await canRunAlone()) return respond({ ok: false });
      await enqueue(jobs);
      respond({ ok: true, auto: true, queued: jobs.length });
    });
    return true;
  }
  if (message.type === "resumefit-ping") {
    void Promise.all([getConnection(), chrome.permissions.contains({ origins: ["https://*/*"] })]).then(
      ([connection, allowed]) => respond({ ok: true, version: chrome.runtime.getManifest().version, autoApply: true, autoSend: true, connected: connection?.apiBase === origin, allowed })
    );
    return true;
  }
  return false;
});
chrome.tabs.onRemoved.addListener((tabId) => void clearPending(tabId));
const MAX_QUEUE = 25;
const LOAD_MS = 3e4;
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function today() {
  const now = /* @__PURE__ */ new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
}
async function canRunAlone() {
  const account = await api.me().catch(() => null);
  if (!account?.autoApply || !account.profile || (account.profile.autoSend ?? "off") === "off" || (account.sendsLeft ?? 0) <= 0) return false;
  return chrome.permissions.contains({ origins: ["https://*/*"] });
}
async function loaded(tabId) {
  for (let waited = 0; waited < LOAD_MS; waited += 500) {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (!tab) throw new Error("The tab was closed.");
    if (tab.status === "complete") break;
    await pause(500);
  }
  await pause(1500);
}
async function askTab(tabId, request) {
  try {
    return await chrome.tabs.sendMessage(tabId, request);
  } catch {
  }
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  return await chrome.tabs.sendMessage(tabId, request);
}
async function enqueue(jobs) {
  const { applyQueue = [] } = await chrome.storage.session.get("applyQueue");
  await chrome.storage.session.set({ applyQueue: [...applyQueue, ...jobs].slice(0, MAX_QUEUE) });
  void drain();
}
let draining = false;
async function drain() {
  if (draining) return;
  draining = true;
  let sent = 0;
  let left = 0;
  try {
    for (; ; ) {
      const { applyQueue = [] } = await chrome.storage.session.get("applyQueue");
      const [job, ...rest] = applyQueue;
      if (!job) break;
      await chrome.storage.session.set({ applyQueue: rest });
      const outcome = await runOne(job);
      if (outcome.sent) sent++;
      else left++;
    }
  } finally {
    draining = false;
  }
  if (sent + left > 1) note("Auto Apply finished", `${sent} sent, ${left} left filled in for you to finish.`);
}
async function runOne(job) {
  let tabId;
  let outcome;
  try {
    const account = await api.me();
    if ((account.profile?.autoSend ?? "off") === "off" || (account.sendsLeft ?? 0) <= 0) throw new Error("You have reached the number of applications you let us send in a day.");
    const tab = await chrome.tabs.create({ url: job.url, active: false });
    tabId = tab.id;
    if (tabId === void 0) throw new Error("The tab could not be opened.");
    const id = tabId;
    await setPending(id, { jobId: job.jobId, resumeId: job.resumeId });
    await loaded(id);
    outcome = await runApplication(account, job, {
      ask: (request) => askTab(id, request),
      goTo: async (url) => {
        await chrome.tabs.update(id, { url });
        await pause(500);
        await loaded(id);
      },
      report: api.reportApplication,
      today: today()
    });
  } catch (problem) {
    outcome = { sent: false, reason: problem instanceof Error ? problem.message : "Something went wrong.", filled: 0, needs: 0 };
  }
  if (outcome.sent) {
    if (tabId !== void 0) void chrome.tabs.remove(tabId).catch(() => void 0);
    note("Application sent", "It is on your tracker under Applied, with the answers that went out.");
  } else {
    if (tabId !== void 0 && job.jobId) void chrome.tabs.remove(tabId).catch(() => void 0);
    note("One application needs you", `${outcome.reason ?? "It was not sent."} Click to answer it in ResumeFit.`);
  }
  return outcome;
}
function note(title, message) {
  void chrome.notifications?.create({ type: "basic", iconUrl: "icon-128.png", title, message });
}
chrome.notifications?.onClicked.addListener((id) => {
  void chrome.notifications.clear(id);
  void getConnection().then((connection) => connection && chrome.tabs.create({ url: `${connection.apiBase}/applications` }));
});
void drain();
