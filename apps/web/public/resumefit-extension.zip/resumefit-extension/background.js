const greenhouse = {
  id: "greenhouse",
  name: "Greenhouse",
  hosts: /(^|\.)greenhouse\.io$/,
  hints: [
    { selector: "#first_name", key: "firstName" },
    { selector: "#last_name", key: "lastName" },
    { selector: "#email", key: "email" },
    { selector: "#phone", key: "phone" },
    { selector: "#candidate-location, #job_application_location", key: "location" },
    { selector: 'input[type="file"]#resume, [data-field="resume"] input[type="file"], #resume_fieldset input[type="file"]', key: "resume" },
    { selector: 'input[type="file"]#cover_letter, [data-field="cover_letter"] input[type="file"]', key: "coverLetter" },
    { selector: "#job_application_gender, #gender", key: "eeoGender" },
    { selector: "#job_application_race, #race, #hispanic_ethnicity", key: "eeoRace" },
    { selector: "#job_application_veteran_status, #veteran_status", key: "eeoVeteran" },
    { selector: "#job_application_disability_status, #disability_status", key: "eeoDisability" }
  ]
};
const lever = {
  id: "lever",
  name: "Lever",
  hosts: /(^|\.)lever\.co$/,
  hints: [
    { selector: 'input[name="name"]', key: "fullName" },
    { selector: 'input[name="email"]', key: "email" },
    { selector: 'input[name="phone"]', key: "phone" },
    { selector: 'input[name="location"]', key: "location" },
    { selector: 'input[name="org"]', key: "currentCompany" },
    { selector: 'input[name="urls[LinkedIn]"]', key: "linkedin" },
    { selector: 'input[name="urls[GitHub]"]', key: "github" },
    { selector: 'input[name="urls[Portfolio]"], input[name="urls[Other]"]', key: "website" },
    { selector: 'input[type="file"][name="resume"]', key: "resume" },
    { selector: 'select[name="eeo[gender]"]', key: "eeoGender" },
    { selector: 'select[name="eeo[race]"]', key: "eeoRace" },
    { selector: 'select[name="eeo[veteran]"]', key: "eeoVeteran" },
    { selector: 'select[name="eeo[disability]"]', key: "eeoDisability" }
  ]
};
const ashby = {
  id: "ashby",
  name: "Ashby",
  hosts: /(^|\.)ashbyhq\.com$/,
  hints: [
    { selector: 'input[name="_systemfield_name"]', key: "fullName" },
    { selector: 'input[name="_systemfield_email"]', key: "email" },
    { selector: 'input[name="_systemfield_phone"], input[type="tel"]', key: "phone" },
    { selector: 'input[name="_systemfield_location"]', key: "location" },
    { selector: 'input[type="file"]#_systemfield_resume, input[type="file"][name="_systemfield_resume"]', key: "resume" }
  ]
};
const workable = {
  id: "workable",
  name: "Workable",
  hosts: /(^|\.)workable\.com$/,
  hints: [
    { selector: 'input[name="firstname"]', key: "firstName" },
    { selector: 'input[name="lastname"]', key: "lastName" },
    { selector: 'input[name="email"]', key: "email" },
    { selector: 'input[name="phone"]', key: "phone" },
    { selector: 'input[name="address"]', key: "location" },
    { selector: 'input[type="file"][data-ui="resume"], [data-ui="resume"] input[type="file"]', key: "resume" }
  ]
};
const workday = {
  id: "workday",
  name: "Workday",
  hosts: /(^|\.)myworkdayjobs\.com$|(^|\.)workday\.com$/,
  multiPage: true,
  hints: [
    { selector: '[data-automation-id="legalNameSection_firstName"], [data-automation-id="firstName"]', key: "firstName" },
    { selector: '[data-automation-id="legalNameSection_lastName"], [data-automation-id="lastName"]', key: "lastName" },
    { selector: '[data-automation-id="email"]', key: "email" },
    { selector: '[data-automation-id="phone-number"], [data-automation-id="phoneNumber"]', key: "phone" },
    { selector: '[data-automation-id="addressSection_city"]', key: "city" },
    { selector: '[data-automation-id="addressSection_postalCode"]', key: "zip" },
    { selector: '[data-automation-id="addressSection_countryRegion"]', key: "state" },
    { selector: '[data-automation-id="countryDropdown"]', key: "country" },
    { selector: '[data-automation-id="file-upload-input-ref"]', key: "resume" },
    { selector: '[data-automation-id="sourceDropdown"], [data-automation-id="sourcePrompt"]', key: "howHeard" },
    { selector: '[data-automation-id="linkedinQuestion"]', key: "linkedin" }
  ]
};
const smartrecruiters = {
  id: "smartrecruiters",
  name: "SmartRecruiters",
  hosts: /(^|\.)smartrecruiters\.com$/,
  hints: [
    { selector: "#first-name-input, input[name='firstName']", key: "firstName" },
    { selector: "#last-name-input, input[name='lastName']", key: "lastName" },
    { selector: "#email-input, input[name='email']", key: "email" },
    { selector: "#linkedin-input", key: "linkedin" }
  ]
};
const icims = { id: "icims", name: "iCIMS", hosts: /(^|\.)icims\.com$/, hints: [] };
const jobvite = { id: "jobvite", name: "Jobvite", hosts: /(^|\.)jobvite\.com$/, hints: [] };
const bamboohr = { id: "bamboohr", name: "BambooHR", hosts: /(^|\.)bamboohr\.com$/, hints: [] };
const taleo = { id: "taleo", name: "Taleo", hosts: /(^|\.)taleo\.net$|(^|\.)oraclecloud\.com$/, hints: [], multiPage: true };
const generic = { id: "generic", name: "This site", hosts: /.*/, hints: [] };
const ADAPTERS = [greenhouse, lever, ashby, workable, workday, smartrecruiters, icims, jobvite, bamboohr, taleo];
function adapterFor(hostname) {
  return ADAPTERS.find((adapter) => adapter.hosts.test(hostname)) ?? generic;
}
const HANDS_FREE_ORIGINS = ["greenhouse.io", "lever.co", "ashbyhq.com", "workable.com", "myworkdayjobs.com", "smartrecruiters.com", "icims.com", "jobvite.com", "bamboohr.com", "taleo.net"].map((host) => `https://*.${host}/*`);
async function getConnection() {
  const { connection } = await chrome.storage.local.get("connection");
  return connection ?? null;
}
class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
  status;
}
async function call(path, body) {
  const connection = await getConnection();
  if (!connection) throw new ApiError("Connect the extension to your ResumeFit account first.", 401);
  let response;
  try {
    response = await fetch(`${connection.apiBase}/api/ext/${path}`, {
      method: body === void 0 ? "GET" : "POST",
      headers: { Authorization: `Bearer ${connection.token}`, ...body === void 0 ? {} : { "Content-Type": "application/json" } },
      body: body === void 0 ? void 0 : JSON.stringify(body)
    });
  } catch {
    throw new ApiError("Could not reach ResumeFit. Check your connection and try again.", 0);
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(data.error ?? "Something went wrong. Try again.", response.status);
  return data;
}
const api = {
  me: () => call("me"),
  saveJob: (job) => call("jobs", job),
  scan: (input) => call("scan", input),
  resumeFile: (id) => call(`resumes/${id}`),
  answer: (input) => call("answer", input),
  saveAnswer: (entry) => call("qa", entry),
  importLinkedin: (profile) => call("linkedin", profile),
  reportApplication: (report2) => call("applications", report2)
};
function profileValues(account) {
  const { profile, current } = account;
  const [first = "", ...rest] = (profile.fullName ?? "").trim().split(/\s+/);
  const yesNo = (value) => value === null ? "" : value ? "Yes" : "No";
  const salary = profile.desiredSalaryMin ?? profile.desiredSalaryMax;
  const values = {
    firstName: first,
    lastName: rest.join(" "),
    fullName: profile.fullName ?? "",
    email: profile.email ?? "",
    phone: profile.phone ?? "",
    linkedin: profile.linkedinUrl ?? "",
    github: profile.githubUrl ?? "",
    website: profile.portfolioUrl ?? "",
    city: profile.city ?? "",
    state: profile.state ?? "",
    country: profile.country ?? "",
    zip: profile.zip ?? "",
    location: [profile.city, profile.state].filter(Boolean).join(", "),
    currentCompany: current.company ?? "",
    currentTitle: current.title ?? "",
    yearsExperience: profile.yearsExperience === null ? "" : String(profile.yearsExperience),
    salary: salary === null ? "" : String(salary),
    startDate: profile.earliestStartDate ?? "",
    // only a clear yes or no is ever given for these
    workAuthorization: /not authorized/i.test(profile.workAuthorization ?? "") ? "No" : profile.workAuthorization ? "Yes" : "",
    sponsorship: yesNo(profile.needsSponsorship),
    relocation: yesNo(profile.willingToRelocate),
    // demographic answers come straight from what the person chose, which starts on decline
    eeoGender: profile.eeoGender,
    eeoRace: profile.eeoRace,
    eeoVeteran: profile.eeoVeteran,
    eeoDisability: profile.eeoDisability
  };
  for (const key2 of Object.keys(values)) if (!values[key2]) delete values[key2];
  return values;
}
const MAX_DRAFTS = 6;
function worthDrafting(field) {
  return field.key === "question" && field.value.trim() === "" && field.label.trim().length >= 5 && (field.required || field.label.includes("?"));
}
function pickResume(account, jobId, wanted) {
  const linked = jobId ? account.resumes.find((resume) => resume.linkedJobId === jobId) : void 0;
  const asked = account.resumes.find((resume) => resume.id === wanted);
  return (linked ?? asked ?? account.resumes.find((resume) => resume.isBase) ?? account.resumes[0])?.id ?? null;
}
async function fillEverything(ask, account, options, source = api) {
  const resume = options.resumeId ? await source.resumeFile(options.resumeId).catch(() => null) : null;
  let fields = await ask({ type: "autofill", values: profileValues(account), resume });
  for (const question of fields.filter(worthDrafting).slice(0, MAX_DRAFTS)) {
    try {
      const result = await source.answer({ question: question.label.slice(0, 500), jdText: options.jdText, resumeId: options.resumeId ?? void 0, jobId: options.jobId ?? void 0 });
      const next = await ask({ type: "set-field", id: question.id, value: result.answer, status: result.source === "saved" ? "filled" : "review" });
      if (next) fields = fields.map((field) => field.id === next.id ? next : field);
    } catch {
    }
  }
  return fields;
}
function canAutoSubmit(fields, page) {
  const { filled, needs } = tally(fields);
  const resumeOk = fields.filter((field) => field.key === "resume").every((field) => field.status === "filled");
  const hasBasics = fields.some((field) => field.key === "email" && field.status === "filled");
  return !page.captcha && !page.multiPage && needs === 0 && filled >= 3 && resumeOk && hasBasics;
}
function tally(fields) {
  return {
    filled: fields.filter((field) => field.status === "filled" || field.status === "review").length,
    needs: fields.filter((field) => field.status === "missing" || field.status === "review").length
  };
}
const key = (tabId) => `run:${tabId}`;
async function getRun(tabId) {
  const stored = await chrome.storage.session.get(key(tabId));
  return stored[key(tabId)] ?? null;
}
async function setRun(tabId, run) {
  await chrome.storage.session.set({ [key(tabId)]: run });
}
async function clearRun(tabId) {
  await chrome.storage.session.remove(key(tabId));
}
const newRun = (url, jobId = null, resumeId = null) => ({ jobId, resumeId, hops: 0, stage: "opening", url, filled: 0, needs: 0 });
function localToday() {
  const now = /* @__PURE__ */ new Date();
  const pad = (value) => String(value).padStart(2, "0");
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
}
chrome.runtime.onInstalled.addListener(() => {
  void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  chrome.contextMenus.create({ id: "resumefit-scan-selection", title: "Scan this job description with ResumeFit", contexts: ["selection"] });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "resumefit-scan-selection" || !info.selectionText || !tab?.id) return;
  void chrome.storage.session.set({ pendingScan: { text: info.selectionText, url: tab.url ?? "", title: tab.title ?? "" } });
  void chrome.sidePanel.open({ tabId: tab.id });
});
chrome.runtime.onMessageExternal.addListener((message, sender, respond) => {
  const origin = sender.url ? new URL(sender.url).origin : "";
  if (message.type === "resumefit-connect" && message.token && message.apiBase === origin) {
    const offer = { apiBase: origin, token: message.token };
    void chrome.storage.session.set({ connectionOffer: offer }).then(() => respond({ ok: true }));
    if (sender.tab?.id) void chrome.sidePanel.open({ tabId: sender.tab.id }).catch(() => void 0);
    return true;
  }
  if (message.type === "resumefit-autofill" && message.jobId) {
    void getConnection().then(async (connection) => {
      if (connection?.apiBase !== origin) return respond({ ok: false });
      await chrome.storage.session.set({ pendingJobId: message.jobId });
      respond({ ok: true });
    });
    return true;
  }
  if (message.type === "resumefit-apply" && Array.isArray(message.jobs)) {
    void getConnection().then(async (connection) => {
      if (connection?.apiBase !== origin) return respond({ ok: false });
      const jobs = (message.jobs ?? []).filter((job) => typeof job?.url === "string" && /^https:\/\//.test(job.url)).slice(0, MAX_AT_ONCE);
      let opened = 0;
      for (const job of jobs) {
        const tab = await chrome.tabs.create({ url: job.url, active: opened === 0, windowId: sender.tab?.windowId, index: sender.tab ? sender.tab.index + 1 + opened : void 0 });
        if (!tab.id) continue;
        const run = newRun(job.url, typeof job.jobId === "string" ? job.jobId : null, typeof job.resumeId === "string" ? job.resumeId : null);
        await setRun(tab.id, run);
        void report(run, "queued", null);
        opened++;
      }
      respond({ ok: opened > 0, opened });
    });
    return true;
  }
  if (message.type === "resumefit-ping") {
    void chrome.permissions.contains({ origins: HANDS_FREE_ORIGINS }).then((handsFree) => respond({ ok: true, version: chrome.runtime.getManifest().version, handsFree }));
    return true;
  }
  return false;
});
const SUBMIT_COUNTDOWN = 8;
const MAX_AT_ONCE = 5;
function report(run, status, ats) {
  return api.reportApplication({ jobId: run.jobId, ats, applyUrl: run.url, status, fieldsFilled: run.filled, fieldsNeedingAttention: run.needs, today: localToday() }).catch(() => void 0);
}
async function advance(tabId, force = false) {
  let run = await getRun(tabId);
  if (!run || run.stage === "filling" || run.stage === "applied") return;
  const ask = (request) => chrome.tabs.sendMessage(tabId, request);
  const say = (bar) => ask({ type: "show-bar", bar }).catch(() => void 0);
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
  } catch {
    await setRun(tabId, { ...run, stage: "blocked" });
    void chrome.action.setBadgeBackgroundColor({ color: "#a34707" });
    void chrome.action.setBadgeText({ tabId, text: "1" });
    void chrome.notifications?.create({ type: "basic", iconUrl: "icon-128.png", title: "One click to fill this application", message: "Click the ResumeFit icon in the toolbar and we fill it in." });
    return;
  }
  void chrome.action.setBadgeText({ tabId, text: "" });
  try {
    const page = await ask({ type: "read-page" });
    if (run.stage === "review" && page.confirmed && !page.hasForm) return await finish(tabId);
    if (!page.hasForm) {
      if (run.stage === "review") return;
      const link = run.hops < 2 ? await ask({ type: "find-apply" }) : null;
      if (link) {
        await setRun(tabId, { ...run, hops: run.hops + 1 });
        await chrome.tabs.update(tabId, { url: link });
      } else await say({ state: "no-form" });
      return;
    }
    if (run.stage === "review" && !force && page.fields.some((field) => field.status !== "skipped")) return;
    run = { ...run, stage: "filling", url: page.url };
    await setRun(tabId, run);
    await say({ state: "working" });
    void report(run, "autofilling", page.ats?.name ?? null);
    const account = await api.me();
    const fields = await fillEverything(ask, account, { resumeId: pickResume(account, run.jobId, run.resumeId), jobId: run.jobId, jdText: page.job?.description ?? "" });
    const multiPage = adapterFor(new URL(page.url).hostname).multiPage === true;
    const done = { state: "done", ...tally(fields), captcha: page.captcha, multiPage };
    const send = account.autoSubmit === true && run.jobId !== null && !run.submitTried && canAutoSubmit(fields, { captcha: page.captcha, multiPage });
    run = { ...run, ...tally(fields), stage: "review", submitTried: run.submitTried || send };
    await setRun(tabId, run);
    void report(run, "needs_review", page.ats?.name ?? null);
    if (send) await ask({ type: "auto-submit", seconds: SUBMIT_COUNTDOWN, done });
    else await say(done);
  } catch (problem) {
    await setRun(tabId, { ...run, stage: "opening" });
    void report(run, "failed", null);
    await say({ state: "error", message: problem instanceof Error ? problem.message : "Something went wrong. Try again." });
  }
}
async function finish(tabId) {
  const run = await getRun(tabId);
  if (!run || run.stage !== "review") return;
  await setRun(tabId, { ...run, stage: "applied" });
  const adapter = adapterFor(new URL(run.url).hostname);
  await report({ ...run, needs: 0 }, "applied", adapter.id === "generic" ? null : adapter.name);
  void chrome.notifications?.create({ type: "basic", iconUrl: "icon-128.png", title: "Application sent", message: "We marked it as applied on your tracker." });
  void chrome.tabs.sendMessage(tabId, { type: "show-bar", bar: { state: "applied" } }).catch(() => void 0);
}
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === "complete") void advance(tabId);
});
chrome.tabs.onRemoved.addListener((tabId) => void clearRun(tabId));
chrome.runtime.onMessage.addListener((message, sender) => {
  const tabId = message.type === "rf-advance" ? message.tabId : sender.tab?.id;
  if (!tabId) return false;
  if (message.type === "rf-confirmed") void finish(tabId);
  else if (message.type === "rf-refill" || message.type === "rf-advance") {
    void (async () => {
      const run = await getRun(tabId);
      if (!run) await setRun(tabId, newRun(sender.tab?.url ?? ""));
      else if (run.stage === "blocked") await setRun(tabId, { ...run, stage: "opening" });
      await advance(tabId, true);
    })();
  }
  return false;
});
