(function() {
  "use strict";
  const greenhouse = {
    id: "greenhouse",
    name: "Greenhouse",
    hosts: /(^|\.)greenhouse\.io$/,
    hints: [
      { selector: "#first_name", key: "firstName" },
      { selector: "#last_name", key: "lastName" },
      { selector: "#email", key: "email" },
      { selector: "#phone", key: "phone" },
      { selector: "#candidate-location, #job_application_location", key: "location" },
      { selector: 'input[type="file"]#resume, [data-field="resume"] input[type="file"], #resume_fieldset input[type="file"]', key: "resume" },
      { selector: 'input[type="file"]#cover_letter, [data-field="cover_letter"] input[type="file"]', key: "coverLetter" },
      { selector: "#job_application_gender, #gender", key: "eeoGender" },
      { selector: "#job_application_race, #race, #hispanic_ethnicity", key: "eeoRace" },
      { selector: "#job_application_veteran_status, #veteran_status", key: "eeoVeteran" },
      { selector: "#job_application_disability_status, #disability_status", key: "eeoDisability" }
    ]
  };
  const lever = {
    id: "lever",
    name: "Lever",
    hosts: /(^|\.)lever\.co$/,
    hints: [
      { selector: 'input[name="name"]', key: "fullName" },
      { selector: 'input[name="email"]', key: "email" },
      { selector: 'input[name="phone"]', key: "phone" },
      { selector: 'input[name="location"]', key: "location" },
      { selector: 'input[name="org"]', key: "currentCompany" },
      { selector: 'input[name="urls[LinkedIn]"]', key: "linkedin" },
      { selector: 'input[name="urls[GitHub]"]', key: "github" },
      { selector: 'input[name="urls[Portfolio]"], input[name="urls[Other]"]', key: "website" },
      { selector: 'input[type="file"][name="resume"]', key: "resume" },
      { selector: 'select[name="eeo[gender]"]', key: "eeoGender" },
      { selector: 'select[name="eeo[race]"]', key: "eeoRace" },
      { selector: 'select[name="eeo[veteran]"]', key: "eeoVeteran" },
      { selector: 'select[name="eeo[disability]"]', key: "eeoDisability" }
    ]
  };
  const ashby = {
    id: "ashby",
    name: "Ashby",
    hosts: /(^|\.)ashbyhq\.com$/,
    hints: [
      { selector: 'input[name="_systemfield_name"]', key: "fullName" },
      { selector: 'input[name="_systemfield_email"]', key: "email" },
      { selector: 'input[name="_systemfield_phone"], input[type="tel"]', key: "phone" },
      { selector: 'input[name="_systemfield_location"]', key: "location" },
      { selector: 'input[type="file"]#_systemfield_resume, input[type="file"][name="_systemfield_resume"]', key: "resume" }
    ]
  };
  const workable = {
    id: "workable",
    name: "Workable",
    hosts: /(^|\.)workable\.com$/,
    hints: [
      { selector: 'input[name="firstname"]', key: "firstName" },
      { selector: 'input[name="lastname"]', key: "lastName" },
      { selector: 'input[name="email"]', key: "email" },
      { selector: 'input[name="phone"]', key: "phone" },
      { selector: 'input[name="address"]', key: "location" },
      { selector: 'input[type="file"][data-ui="resume"], [data-ui="resume"] input[type="file"]', key: "resume" }
    ]
  };
  const workday = {
    id: "workday",
    name: "Workday",
    hosts: /(^|\.)myworkdayjobs\.com$|(^|\.)workday\.com$/,
    multiPage: true,
    hints: [
      { selector: '[data-automation-id="legalNameSection_firstName"], [data-automation-id="firstName"]', key: "firstName" },
      { selector: '[data-automation-id="legalNameSection_lastName"], [data-automation-id="lastName"]', key: "lastName" },
      { selector: '[data-automation-id="email"]', key: "email" },
      { selector: '[data-automation-id="phone-number"], [data-automation-id="phoneNumber"]', key: "phone" },
      { selector: '[data-automation-id="addressSection_city"]', key: "city" },
      { selector: '[data-automation-id="addressSection_postalCode"]', key: "zip" },
      { selector: '[data-automation-id="addressSection_countryRegion"]', key: "state" },
      { selector: '[data-automation-id="countryDropdown"]', key: "country" },
      { selector: '[data-automation-id="file-upload-input-ref"]', key: "resume" },
      { selector: '[data-automation-id="sourceDropdown"], [data-automation-id="sourcePrompt"]', key: "howHeard" },
      { selector: '[data-automation-id="linkedinQuestion"]', key: "linkedin" }
    ]
  };
  const smartrecruiters = {
    id: "smartrecruiters",
    name: "SmartRecruiters",
    hosts: /(^|\.)smartrecruiters\.com$/,
    hints: [
      { selector: "#first-name-input, input[name='firstName']", key: "firstName" },
      { selector: "#last-name-input, input[name='lastName']", key: "lastName" },
      { selector: "#email-input, input[name='email']", key: "email" },
      { selector: "#linkedin-input", key: "linkedin" }
    ]
  };
  const icims = { id: "icims", name: "iCIMS", hosts: /(^|\.)icims\.com$/, hints: [] };
  const jobvite = { id: "jobvite", name: "Jobvite", hosts: /(^|\.)jobvite\.com$/, hints: [] };
  const bamboohr = { id: "bamboohr", name: "BambooHR", hosts: /(^|\.)bamboohr\.com$/, hints: [] };
  const taleo = { id: "taleo", name: "Taleo", hosts: /(^|\.)taleo\.net$|(^|\.)oraclecloud\.com$/, hints: [], multiPage: true };
  const generic = { id: "generic", name: "This site", hosts: /.*/, hints: [] };
  const ADAPTERS = [greenhouse, lever, ashby, workable, workday, smartrecruiters, icims, jobvite, bamboohr, taleo];
  function adapterFor(hostname) {
    return ADAPTERS.find((adapter) => adapter.hosts.test(hostname)) ?? generic;
  }
  const APPLY_TEXT = /^(apply|apply now|apply here|apply today|apply online|apply for (this|the) (job|role|position)|apply to (this|the) (job|role|position)|start (your )?application|i'?m interested)$/i;
  function findApplyLink(doc, url) {
    const frame = doc.querySelector('iframe[src*="greenhouse.io/embed/job_app"]');
    const candidates = [frame?.getAttribute("src"), ...[...doc.querySelectorAll("a[href]")].filter((link) => APPLY_TEXT.test((link.textContent ?? "").replace(/\s+/g, " ").trim())).map((link) => link.getAttribute("href"))];
    for (const href of candidates) {
      if (!href || href.startsWith("#")) continue;
      try {
        const target = new URL(href, url);
        if (target.protocol === "https:" && target.href.split("#")[0] !== url.split("#")[0]) return target.href;
      } catch {
      }
    }
    return null;
  }
  const HOST_ID = "resumefit-bar";
  const STYLES = `
  :host { all: initial; }
  .bar {
    position: fixed; left: 50%; bottom: 18px; z-index: 2147483647;
    display: flex; align-items: center; gap: 12px; max-width: min(640px, calc(100vw - 24px));
    padding: 10px 12px 10px 14px; border-radius: 14px; border: 1px solid #e4e2da; background: #ffffff; color: #1c1b18;
    font: 13px/1.4 system-ui, -apple-system, "Segoe UI", sans-serif;
    box-shadow: 0 1px 2px rgb(28 27 24 / 0.06), 0 12px 32px rgb(28 27 24 / 0.16);
    transform: translate(-50%, 0); opacity: 1;
    transition: transform 0.26s cubic-bezier(0.22, 1, 0.36, 1), opacity 0.2s ease-out;
  }
  /* slides up from the edge when it first shows */
  @starting-style { .bar { transform: translate(-50%, 16px); opacity: 0; } }
  .dot { flex: none; width: 10px; height: 10px; border-radius: 50%; background: #2a7a4b; }
  .dot.warn { background: #a86400; }
  .dot.bad { background: #c2362b; }
  /* spinner shown while the form is being filled */
  .dot.spin { background: none; width: 14px; height: 14px; border: 2px solid #e4e2da; border-top-color: #a34707; animation: turn 0.7s linear infinite; }
  @keyframes turn { to { transform: rotate(360deg); } }
  .text { flex: 1; min-width: 0; }
  .title { font-weight: 650; }
  .note { color: #5f5e58; font-size: 12px; }
  /* styling for buttons */
  button {
    all: unset; flex: none; cursor: pointer; padding: 6px 10px; border-radius: 9px; border: 1px solid #e4e2da;
    font: 600 12px/1.3 system-ui, -apple-system, "Segoe UI", sans-serif; color: #1c1b18; background: #ffffff;
    transition: transform 0.15s ease-out, background 0.15s ease;
  }
  button:hover { background: #f7f6f2; }
  button:active { transform: scale(0.97); }
  button:focus-visible { outline: 2px solid #a34707; outline-offset: 2px; }
  button.main { background: #a34707; border-color: #a34707; color: #ffffff; }
  button.main:hover { background: #863a06; }
  button.close { border: 0; padding: 4px 6px; color: #5f5e58; font-size: 16px; line-height: 1; }
  @media (prefers-reduced-motion: reduce) { .bar { transition: none; } .dot.spin { animation-duration: 2s; } }
`;
  function wording(bar) {
    if (bar.state === "working") return { title: "ResumeFit is filling this in", note: "Your details, your resume and the written questions. Nothing is sent.", dot: "spin" };
    if (bar.state === "applied") return { title: "Application sent", note: "Marked as applied on your tracker.", dot: "" };
    if (bar.state === "no-form") return { title: "No application form on this page yet", note: "Press the site's Apply button. We fill the form in when it shows.", dot: "warn" };
    if (bar.state === "error") return { title: "Could not fill this one", note: bar.message, dot: "bad" };
    const fields2 = `${bar.filled} ${bar.filled === 1 ? "field" : "fields"}`;
    const note = [
      bar.needs === 0 ? "Read it over, then press the site's own Submit button." : `Check ${bar.needs === 1 ? "it" : "those"}, then press the site's own Submit button.`,
      bar.captcha ? "The captcha is yours to do." : "",
      bar.multiPage ? "On the next page, press Fill this page." : ""
    ].filter(Boolean).join(" ");
    return { title: bar.needs === 0 ? `Filled ${fields2}. Ready for you to review` : `Filled ${fields2}, ${bar.needs} ${bar.needs === 1 ? "needs" : "need"} you`, note, dot: bar.needs === 0 ? "" : "warn" };
  }
  function showBar(doc, bar, actions) {
    doc.getElementById(HOST_ID)?.remove();
    const host = doc.createElement("div");
    host.id = HOST_ID;
    const root = host.attachShadow({ mode: "open" });
    const style = doc.createElement("style");
    style.textContent = STYLES;
    const box = doc.createElement("div");
    box.className = "bar";
    box.setAttribute("role", "status");
    const make = (tag, className, text2 = "") => {
      const element = doc.createElement(tag);
      element.className = className;
      element.textContent = text2;
      return element;
    };
    const { title, note, dot } = wording(bar);
    const text = make("div", "text");
    text.append(make("div", "title", title), make("div", "note", note));
    box.append(make("span", `dot ${dot}`), text);
    if (bar.state === "done" && bar.needs > 0) {
      const next = make("button", "main", "Show next");
      next.addEventListener("click", actions.onNext);
      box.append(next);
    }
    if (bar.state === "done" || bar.state === "error") {
      const again = make("button", "", bar.state === "done" && bar.multiPage ? "Fill this page" : "Fill again");
      again.addEventListener("click", actions.onRefill);
      box.append(again);
    }
    if (bar.state !== "working") {
      const close = make("button", "close", "×");
      close.setAttribute("aria-label", "Hide ResumeFit");
      close.addEventListener("click", () => host.remove());
      box.append(close);
    }
    root.append(style, box);
    doc.documentElement.append(host);
  }
  const FIELD_PATTERNS = [
    // demographic questions first, so "gender" is never mistaken for something else
    ["eeoGender", /\bgender\b|\bsex\b/],
    ["eeoRace", /\brace\b|ethnic|hispanic|latino/],
    ["eeoVeteran", /veteran/],
    ["eeoDisability", /disabilit/],
    ["sponsorship", /sponsor|visa status|require.*(visa|h-?1b)/],
    ["workAuthorization", /authori[sz]ed to work|work authori[sz]ation|legally (authori[sz]ed|eligible|able|permitted)|eligible to work|right to work/],
    ["relocation", /relocat/],
    ["howHeard", /how did you (hear|find|learn)|where did you (hear|find)|referral source|source of (application|referral)/],
    ["resume", /resume|résumé|\bcv\b|curriculum vitae/],
    ["coverLetter", /cover letter/],
    ["linkedin", /linkedin/],
    ["github", /github/],
    ["website", /website|portfolio|personal (site|url|page)|\bblog\b|other (url|link)/],
    ["firstName", /first name|given name|forename|\bfname\b|firstname|preferred name/],
    ["lastName", /last name|family name|surname|\blname\b|lastname/],
    ["fullName", /full name|legal name|your name|^name$|\bname\b/],
    ["email", /e-?mail/],
    ["phone", /phone|mobile|\btel\b|telephone|cell/],
    ["zip", /\bzip\b|postal|postcode/],
    ["city", /\bcity\b|\btown\b/],
    ["state", /\bstate\b|province|\bregion\b/],
    ["country", /country/],
    ["location", /location|where are you (based|located)|current address|^address/],
    ["currentCompany", /current (company|employer)|present employer|^company$|^employer$|\borg(ani[sz]ation)?\b/],
    ["currentTitle", /current (title|role|position)|job title|^title$/],
    // only the total, never "years of experience with sql", which we cannot know
    ["yearsExperience", /(total )?years of (relevant |professional |work |total )?experience(?! (do you have )?(with|in|using|as)\b)|experience \(years\)/],
    ["salary", /salary|compensation|pay (expectation|range|rate)|desired pay|expected (ctc|pay)/],
    ["startDate", /start date|available to start|when can you start|availability|notice period/]
  ];
  const AUTOCOMPLETE = {
    "given-name": "firstName",
    "family-name": "lastName",
    name: "fullName",
    email: "email",
    tel: "phone",
    "tel-national": "phone",
    "address-level2": "city",
    "address-level1": "state",
    "postal-code": "zip",
    country: "country",
    "country-name": "country",
    organization: "currentCompany",
    "organization-title": "currentTitle",
    url: "website"
  };
  function normalize(text) {
    return text.toLowerCase().replace(/[_\-[\].]+/g, " ").replace(/[*:?()]/g, " ").replace(/\s+/g, " ").trim();
  }
  function matchKey(texts) {
    for (const raw of texts) {
      const text = normalize(raw);
      if (!text) continue;
      for (const [key, pattern] of FIELD_PATTERNS) if (pattern.test(text)) return key;
    }
    return null;
  }
  const DECLINE_PATTERN = /decline|prefer not|(don.t|do not) (wish|want)|not to (say|answer|disclose|identify)|choose not|rather not/i;
  const SKIP_TYPES = /* @__PURE__ */ new Set(["hidden", "submit", "button", "reset", "image", "password", "search", "range", "color"]);
  function textOf(element) {
    return (element?.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function labelFor(control, doc) {
    const aria = control.getAttribute("aria-label");
    if (aria?.trim()) return aria.trim();
    const labelledBy = control.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id) => textOf(doc.getElementById(id))).join(" ").trim();
      if (text) return text;
    }
    if (control.id) {
      const label = [...doc.querySelectorAll("label")].find((entry) => entry.getAttribute("for") === control.id);
      if (label && textOf(label)) return textOf(label);
    }
    const wrapping = control.closest("label");
    if (wrapping && textOf(wrapping)) return textOf(wrapping);
    let node = control;
    for (let depth = 0; node && depth < 3; depth++, node = node.parentElement) {
      const previous = node.previousElementSibling;
      if (previous && /^(LABEL|SPAN|DIV|P)$/.test(previous.tagName) && !previous.querySelector("input, select, textarea") && textOf(previous) && textOf(previous).length < 200) return textOf(previous);
      if (previous) break;
    }
    return control.getAttribute("placeholder")?.trim() ?? "";
  }
  function groupLabel(control, doc) {
    const fieldset = control.closest("fieldset");
    const legend = fieldset?.querySelector("legend");
    if (legend && textOf(legend)) return textOf(legend);
    const group = control.closest('[role="radiogroup"], [role="group"]');
    if (group) {
      const label = labelFor(group, doc);
      if (label) return label;
    }
    const name = control.getAttribute("name") ?? "";
    const total = name ? doc.querySelectorAll(`input[name="${CSS.escape(name)}"]`).length : 1;
    let parent = control.parentElement;
    for (let depth = 0; parent && depth < 8; depth++, parent = parent.parentElement) {
      if (name && parent.querySelectorAll(`input[name="${CSS.escape(name)}"]`).length < total) continue;
      const heading = [...parent.children].find((child) => !child.querySelector("input, select, textarea") && !/^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(child.tagName) && textOf(child));
      if (heading) return textOf(heading);
    }
    return "";
  }
  function isRequired(control, label) {
    return control.hasAttribute("required") || control.getAttribute("aria-required") === "true" || /\*\s*$|\(required\)/i.test(label);
  }
  function findFields(doc, adapter) {
    const controls = [...doc.querySelectorAll("input, select, textarea")].filter((control) => {
      if (control instanceof HTMLInputElement && SKIP_TYPES.has(control.type)) return false;
      return !control.disabled && !control.closest('[aria-hidden="true"], [hidden]');
    });
    const fields2 = [];
    const groups = /* @__PURE__ */ new Map();
    for (const control of controls) {
      const type = control instanceof HTMLInputElement ? control.type : control.tagName.toLowerCase();
      const isChoice = type === "radio" || type === "checkbox";
      const name = control.getAttribute("name") ?? "";
      const grouped = isChoice && name !== "" && (type === "radio" || doc.querySelectorAll(`input[type="checkbox"][name="${CSS.escape(name)}"]`).length > 1);
      if (grouped) {
        const existing = groups.get(name);
        if (existing) {
          existing.elements.push(control);
          continue;
        }
      }
      if (type === "checkbox" && !grouped) continue;
      const label = grouped ? groupLabel(control, doc) || labelFor(control, doc) : labelFor(control, doc);
      const hinted = adapter.hints.find((hint) => control.matches(hint.selector))?.key ?? null;
      const autocomplete = AUTOCOMPLETE[(control.getAttribute("autocomplete") ?? "").split(" ").at(-1) ?? ""] ?? null;
      let key = hinted ?? autocomplete ?? matchKey([label, name, control.id, control.getAttribute("placeholder") ?? ""]);
      const kind = type === "file" ? "file" : type === "radio" ? "radio" : type === "checkbox" ? "checkbox" : type === "select" || type === "select-one" ? "select" : type === "textarea" ? "textarea" : "text";
      if (kind === "file" && key !== "resume" && key !== "coverLetter") key = null;
      if (!key && (kind === "textarea" || kind === "text" && /\?\s*\*?$/.test(label) && label.length > 25)) key = "question";
      if (kind === "textarea" && !hinted) key = "question";
      const field = { id: `rf-${fields2.length}`, key, label: label || name || control.id || "Unlabelled field", kind, required: isRequired(control, label), elements: [control] };
      for (const element of field.elements) element.setAttribute("data-resumefit-field", field.id);
      fields2.push(field);
      if (grouped) groups.set(name, field);
    }
    for (const field of groups.values()) for (const element of field.elements) element.setAttribute("data-resumefit-field", field.id);
    if (!fields2.some((field) => field.key === "resume")) {
      const loose = fields2.filter((field) => field.kind === "file" && field.key === null);
      if (loose.length === 1 && loose[0]) loose[0].key = "resume";
    }
    return fields2;
  }
  function looksLikeApplication(fields2) {
    const keys = new Set(fields2.map((field) => field.key));
    const hasName = keys.has("firstName") || keys.has("fullName") || keys.has("lastName");
    return hasName && keys.has("email") || keys.has("resume");
  }
  const EEO_KEYS = ["eeoGender", "eeoRace", "eeoVeteran", "eeoDisability"];
  function setNativeValue(element, value) {
    const view = element.ownerDocument.defaultView ?? window;
    const prototype = element instanceof view.HTMLTextAreaElement ? view.HTMLTextAreaElement.prototype : element instanceof view.HTMLSelectElement ? view.HTMLSelectElement.prototype : view.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
    element.dispatchEvent(new view.Event("input", { bubbles: true }));
    element.dispatchEvent(new view.Event("change", { bubbles: true }));
    element.dispatchEvent(new view.Event("blur", { bubbles: true }));
  }
  function pickOption(options, answer, key) {
    const wanted = normalize(answer);
    const texts = options.map((option) => normalize(option.text));
    const real = (index) => texts[index] !== "" && !/^(select|choose|please select|--)/.test(texts[index] ?? "");
    if (DECLINE_PATTERN.test(answer)) return texts.findIndex((text, index) => real(index) && DECLINE_PATTERN.test(text));
    const exact = texts.findIndex((text, index) => real(index) && (text === wanted || normalize(options[index]?.value ?? "") === wanted));
    if (exact !== -1) return exact;
    if (wanted === "yes" || wanted === "no") return texts.findIndex((text, index) => real(index) && new RegExp(`^${wanted}\\b`).test(text));
    if (key && EEO_KEYS.includes(key)) return texts.findIndex((text, index) => real(index) && (text.startsWith(wanted) || wanted.startsWith(text)));
    return texts.findIndex((text, index) => real(index) && text.length > 1 && (text.includes(wanted) || wanted.includes(text)));
  }
  function attachFile(input, file) {
    try {
      const view = input.ownerDocument.defaultView ?? window;
      const bytes = Uint8Array.from(atob(file.base64), (char) => char.charCodeAt(0));
      const transfer = new view.DataTransfer();
      transfer.items.add(new view.File([bytes], file.name, { type: file.type }));
      input.files = transfer.files;
      input.dispatchEvent(new view.Event("input", { bubbles: true }));
      input.dispatchEvent(new view.Event("change", { bubbles: true }));
      return (input.files?.length ?? 0) > 0;
    } catch {
      return false;
    }
  }
  function optionText(element) {
    const doc = element.ownerDocument;
    const byFor = element.id ? [...doc.querySelectorAll("label")].find((label) => label.getAttribute("for") === element.id) : null;
    return (byFor?.textContent ?? element.closest("label")?.textContent ?? element.getAttribute("aria-label") ?? element.getAttribute("value") ?? "").replace(/\s+/g, " ").trim();
  }
  function currentValue(field) {
    const [first] = field.elements;
    if (!first) return "";
    if (field.kind === "radio" || field.kind === "checkbox") {
      return field.elements.filter((element) => element.checked).map(optionText).join(", ");
    }
    if (field.kind === "file") return first.files?.[0]?.name ?? "";
    if (field.kind === "select") {
      const select = first;
      const chosen = select.options[select.selectedIndex];
      return chosen && chosen.value !== "" ? chosen.text.trim() : "";
    }
    return first.value;
  }
  function fillField(field, answer, resume) {
    const [first] = field.elements;
    if (!first) return "skipped";
    const empty = field.required ? "missing" : "skipped";
    if (field.kind === "file") {
      if (field.key !== "resume" || !resume) return empty;
      return attachFile(first, resume) ? "filled" : "missing";
    }
    if (!answer) return empty;
    if (field.kind === "select") {
      const select = first;
      const index = pickOption([...select.options].map((option) => ({ text: option.text, value: option.value })), answer, field.key);
      if (index === -1) return empty;
      setNativeValue(select, select.options[index]?.value ?? "");
      return "filled";
    }
    if (field.kind === "radio" || field.kind === "checkbox") {
      const index = pickOption(field.elements.map((element) => ({ text: optionText(element), value: element.getAttribute("value") ?? "" })), answer, field.key);
      const choice = field.elements[index];
      if (!choice) return empty;
      if (!choice.checked) choice.click();
      return "filled";
    }
    setNativeValue(first, answer);
    return "filled";
  }
  function fillForm(fields2, values, resume) {
    return fields2.map((field) => {
      const answer = field.key && field.key !== "question" ? values[field.key] : void 0;
      const status = field.key === "question" ? field.required ? "missing" : "skipped" : fillField(field, answer, resume);
      return { id: field.id, key: field.key, label: field.label, kind: field.kind, required: field.required, status, value: currentValue(field) };
    });
  }
  const OUTLINES = { filled: "#15803d", review: "#b45309", missing: "#b91c1c", skipped: "" };
  function highlight(field, status) {
    for (const element of field.elements) {
      const target = field.kind === "radio" || field.kind === "checkbox" ? element.closest("label") ?? element : element;
      target.style.outline = OUTLINES[status] ? `2px solid ${OUTLINES[status]}` : "";
      target.style.outlineOffset = OUTLINES[status] ? "2px" : "";
      element.setAttribute("data-resumefit-status", status);
    }
  }
  const SITES = [
    {
      hosts: /linkedin\.com$/,
      title: ".job-details-jobs-unified-top-card__job-title, .top-card-layout__title, .jobs-unified-top-card__job-title",
      company: ".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link, .jobs-unified-top-card__company-name",
      location: ".job-details-jobs-unified-top-card__primary-description-container span, .topcard__flavor--bullet",
      description: "#job-details, .jobs-description__content, .show-more-less-html__markup"
    },
    {
      hosts: /indeed\.com$/,
      title: '[data-testid="jobsearch-JobInfoHeader-title"], .jobsearch-JobInfoHeader-title',
      company: '[data-testid="inlineHeader-companyName"], [data-company-name="true"]',
      location: '[data-testid="inlineHeader-companyLocation"], [data-testid="job-location"]',
      description: "#jobDescriptionText"
    },
    {
      hosts: /glassdoor\.[a-z.]+$/,
      title: '[data-test="job-title"], h1[id^="jd-job-title"]',
      company: '[data-test="employer-name"], [class*="EmployerProfile_employerName"]',
      location: '[data-test="location"]',
      description: '[class*="JobDetails_jobDescription"], .jobDescriptionContent'
    },
    { hosts: /greenhouse\.io$/, title: "h1.app-title, .job__title h1, h1", company: ".company-name, .job__header .company", location: ".location, .job__location", description: "#content, .job__description" },
    { hosts: /lever\.co$/, title: ".posting-headline h2", company: ".main-header-logo img", location: ".posting-categories .location", description: '[data-qa="job-description"], .section-wrapper.page-full-width' },
    { hosts: /ashbyhq\.com$/, title: "h1", company: 'meta[property="og:site_name"]', location: '[class*="_location"]', description: '[class*="_descriptionText"], #overview' }
  ];
  function read(doc, selector) {
    if (!selector) return "";
    const element = doc.querySelector(selector);
    if (!element) return "";
    const text = element.getAttribute("content") ?? element.getAttribute("alt") ?? blockText(element);
    return text.replace(/[ \t]+/g, " ").trim();
  }
  function blockText(element) {
    const parts = [];
    const walk = (node) => {
      if (node.nodeType === 3) parts.push(node.textContent ?? "");
      else if (node.nodeType === 1) {
        const tag = node.tagName;
        if (/^(SCRIPT|STYLE|NOSCRIPT|SVG)$/.test(tag)) return;
        const block = /^(P|DIV|LI|UL|OL|H[1-6]|BR|SECTION|TR)$/.test(tag);
        if (block) parts.push("\n");
        if (tag === "LI") parts.push("• ");
        node.childNodes.forEach(walk);
        if (block) parts.push("\n");
      }
    };
    walk(element);
    return parts.join("").replace(/[ \t]+/g, " ").replace(/ ?\n ?/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function stripTags(html, doc) {
    const View = doc.defaultView ?? window;
    const inert = new View.DOMParser().parseFromString(html, "text/html");
    return blockText(inert.body);
  }
  function fromStructuredData(doc) {
    for (const script of doc.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const parsed = JSON.parse(script.textContent ?? "");
        const items = Array.isArray(parsed) ? parsed : [parsed, ...parsed?.["@graph"] ?? []];
        const posting = items.find((item) => item?.["@type"] === "JobPosting");
        if (!posting) continue;
        const organization = posting.hiringOrganization;
        const place = [posting.jobLocation].flat()[0];
        return {
          title: String(posting.title ?? ""),
          company: organization?.name ?? "",
          location: [place?.address?.addressLocality, place?.address?.addressRegion].filter(Boolean).join(", "),
          description: stripTags(String(posting.description ?? ""), doc)
        };
      } catch {
      }
    }
    return null;
  }
  function biggestBlock(doc) {
    let best = "";
    for (const element of doc.querySelectorAll("main, article, section, [role='main'], div")) {
      if (element.querySelectorAll("input, select, textarea").length > 3) continue;
      const text = blockText(element);
      const links = [...element.querySelectorAll("a")].reduce((total, link) => total + (link.textContent?.length ?? 0), 0);
      if (text.length > best.length && text.length < 3e4 && links < text.length * 0.3 && /experience|responsibilit|qualificat|requirement|skills/i.test(text)) best = text;
    }
    return best;
  }
  function readJob(doc, url) {
    const hostname = new URL(url).hostname;
    const site = SITES.find((entry) => entry.hosts.test(hostname));
    const structured = fromStructuredData(doc);
    const title = structured?.title || site && read(doc, site.title) || read(doc, "h1") || read(doc, 'meta[property="og:title"]');
    const description = structured?.description || site && read(doc, site.description) || biggestBlock(doc);
    if (!title || description.length < 200) return null;
    return {
      title: title.slice(0, 200),
      company: (structured?.company || site && read(doc, site.company) || read(doc, 'meta[property="og:site_name"]')).slice(0, 200),
      location: (structured?.location || site && read(doc, site.location) || "").slice(0, 200),
      description: description.slice(0, 4e4),
      url
    };
  }
  function hasCaptcha(doc) {
    return doc.querySelector('iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="turnstile"], .g-recaptcha, .h-captcha, [data-sitekey], #px-captcha') !== null;
  }
  function visibleText(element, limit) {
    const parts = [];
    let length = 0;
    const walk = (node) => {
      if (length > limit) return;
      if (node.nodeType === 3) {
        parts.push(node.textContent ?? "");
        length += node.textContent?.length ?? 0;
      } else if (node.nodeType === 1) {
        const child = node;
        if (/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|SVG)$/i.test(child.tagName) || child.hidden || child.getAttribute("aria-hidden") === "true") return;
        if (typeof child.checkVisibility === "function" && !child.checkVisibility()) return;
        child.childNodes.forEach(walk);
      }
    };
    walk(element);
    return parts.join(" ").replace(/\s+/g, " ");
  }
  function looksConfirmed(doc) {
    const main = doc.querySelector("main, [role='main'], body");
    const text = main ? visibleText(main, 6e3).slice(0, 6e3) : "";
    return /thank you for applying|thanks for applying|application (has been |was )?(submitted|received|sent)|we('ve| have) received your application|your application is complete|successfully applied/i.test(text);
  }
  function isLinkedinProfile(url) {
    if (!URL.canParse(url)) return false;
    const { hostname, pathname } = new URL(url);
    return /(^|\.)linkedin\.com$/.test(hostname) && /^\/in\/[^/]+/.test(pathname);
  }
  const clean = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  const NOISE = /^(show all\b.*|…?\s*see more|see less|show more|show less|show credential|·.*|\d+ endorsements?|endorsed by .*|\d+ (experiences?|educations?) (at|across) .*|passed linkedin skill assessment)$/i;
  function visibleLines(root) {
    const spans = [...root.querySelectorAll('span[aria-hidden="true"]')].map((span) => clean(span.textContent));
    const raw = spans.some(Boolean) ? spans : (root.textContent ?? "").split("\n").map(clean);
    const lines = [];
    for (const line of raw) {
      if (!line || NOISE.test(line) || lines.at(-1) === line) continue;
      lines.push(line);
    }
    return lines;
  }
  function part(doc, id) {
    const section = doc.getElementById(id)?.closest("section") ?? doc.querySelector(`section[data-section="${id}"]`);
    if (!section) return [];
    const lines = visibleLines(section);
    return lines[0]?.toLowerCase() === id ? lines.slice(1) : lines;
  }
  function readLinkedinProfile(doc, url) {
    const main = doc.querySelector("main") ?? doc.body;
    const name = clean(main.querySelector("h1")?.textContent);
    let headline = clean(main.querySelector(".text-body-medium")?.textContent);
    if (!headline && name) {
      const top = main.querySelector("h1")?.closest("section");
      const lines = top ? (top.textContent ?? "").split("\n").map(clean).filter(Boolean) : [];
      headline = lines.slice(lines.indexOf(name) + 1).find((line) => line.length > 10 && !/^(he|she|they)\b|\b(1st|2nd|3rd)\b|contact info|connections|followers/i.test(line)) ?? "";
    }
    const address = URL.canParse(url) ? `linkedin.com${new URL(url).pathname.match(/^\/in\/[^/]+/)?.[0] ?? ""}` : "";
    return {
      headline: headline.slice(0, 400),
      about: part(doc, "about").join("\n").slice(0, 6e3),
      experience: part(doc, "experience").join("\n").slice(0, 2e4),
      // skill names are short, anything long is a description that slipped in
      skills: [...new Set(part(doc, "skills").filter((line) => line.length <= 50))].slice(0, 100),
      url: address
    };
  }
  let fields = [];
  function report(field, status) {
    return { id: field.id, key: field.key, label: field.label, kind: field.kind, required: field.required, status, value: currentValue(field) };
  }
  function readPage() {
    const adapter = adapterFor(location.hostname);
    fields = findFields(document, adapter);
    const hasForm = looksLikeApplication(fields);
    return {
      url: location.href,
      ats: adapter.id === "generic" ? null : { id: adapter.id, name: adapter.name },
      job: readJob(document, location.href),
      hasForm,
      fields: hasForm ? fields.map((field) => report(field, field.elements[0]?.getAttribute("data-resumefit-status") ?? "skipped")) : [],
      captcha: hasCaptcha(document),
      confirmed: looksConfirmed(document),
      linkedinProfile: isLinkedinProfile(location.href)
    };
  }
  const tellWorker = (message) => void chrome.runtime.sendMessage(message).catch(() => void 0);
  let cursor = -1;
  function showNext() {
    const waiting = fields.filter((field) => /^(missing|review)$/.test(field.elements[0]?.getAttribute("data-resumefit-status") ?? ""));
    if (waiting.length === 0) return;
    cursor = (cursor + 1) % waiting.length;
    const element = waiting[cursor]?.elements[0];
    element?.scrollIntoView({ behavior: "smooth", block: "center" });
    element?.focus({ preventScroll: true });
  }
  let watching = false;
  function watchForConfirmation() {
    if (watching || looksConfirmed(document)) return;
    watching = true;
    let timer;
    const observer = new MutationObserver(() => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        if (!looksConfirmed(document) || looksLikeApplication(findFields(document, adapterFor(location.hostname)))) return;
        observer.disconnect();
        tellWorker({ type: "rf-confirmed" });
      }, 1200);
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }
  if (!window.__resumefitLoaded) {
    window.__resumefitLoaded = true;
    chrome.runtime.onMessage.addListener((request, _sender, respond) => {
      if (request.type === "read-page") {
        respond(readPage());
      } else if (request.type === "autofill") {
        fields = findFields(document, adapterFor(location.hostname));
        const results = fillForm(fields, request.values, request.resume);
        for (const result of results) {
          const field = fields.find((entry) => entry.id === result.id);
          if (field) highlight(field, result.status);
        }
        respond(results);
      } else if (request.type === "set-field") {
        const field = fields.find((entry) => entry.id === request.id);
        if (field) {
          const status = fillField(field, request.value, null) === "filled" ? request.status : "missing";
          highlight(field, status);
          respond(report(field, status));
        } else respond(null);
      } else if (request.type === "focus-field") {
        const element = fields.find((entry) => entry.id === request.id)?.elements[0];
        element?.scrollIntoView({ behavior: "smooth", block: "center" });
        element?.focus({ preventScroll: true });
        respond(true);
      } else if (request.type === "read-linkedin") {
        respond(readLinkedinProfile(document, location.href));
      } else if (request.type === "find-apply") {
        respond(findApplyLink(document, location.href));
      } else if (request.type === "show-bar") {
        showBar(document, request.bar, { onNext: showNext, onRefill: () => tellWorker({ type: "rf-refill" }) });
        if (request.bar.state === "done") watchForConfirmation();
        respond(true);
      } else if (request.type === "selection") {
        respond(String(getSelection() ?? ""));
      }
      return false;
    });
  }
})();
