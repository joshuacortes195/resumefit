(function() {
  "use strict";
  const SITES = [
    {
      hosts: /linkedin\.com$/,
      title: ".job-details-jobs-unified-top-card__job-title, .top-card-layout__title, .jobs-unified-top-card__job-title",
      company: ".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link, .jobs-unified-top-card__company-name",
      location: ".job-details-jobs-unified-top-card__primary-description-container span, .topcard__flavor--bullet",
      description: "#job-details, .jobs-description__content, .show-more-less-html__markup"
    },
    {
      hosts: /indeed\.com$/,
      title: '[data-testid="jobsearch-JobInfoHeader-title"], .jobsearch-JobInfoHeader-title',
      company: '[data-testid="inlineHeader-companyName"], [data-company-name="true"]',
      location: '[data-testid="inlineHeader-companyLocation"], [data-testid="job-location"]',
      description: "#jobDescriptionText"
    },
    {
      hosts: /glassdoor\.[a-z.]+$/,
      title: '[data-test="job-title"], h1[id^="jd-job-title"]',
      company: '[data-test="employer-name"], [class*="EmployerProfile_employerName"]',
      location: '[data-test="location"]',
      description: '[class*="JobDetails_jobDescription"], .jobDescriptionContent'
    },
    { hosts: /greenhouse\.io$/, title: "h1.app-title, .job__title h1, h1", company: ".company-name, .job__header .company", location: ".location, .job__location", description: "#content, .job__description" },
    { hosts: /lever\.co$/, title: ".posting-headline h2", company: ".main-header-logo img", location: ".posting-categories .location", description: '[data-qa="job-description"], .section-wrapper.page-full-width' },
    { hosts: /ashbyhq\.com$/, title: "h1", company: 'meta[property="og:site_name"]', location: '[class*="_location"]', description: '[class*="_descriptionText"], #overview' }
  ];
  function read(doc, selector) {
    if (!selector) return "";
    const element = doc.querySelector(selector);
    if (!element) return "";
    const text = element.getAttribute("content") ?? element.getAttribute("alt") ?? blockText(element);
    return text.replace(/[ \t]+/g, " ").trim();
  }
  function blockText(element) {
    const parts = [];
    const walk = (node) => {
      if (node.nodeType === 3) parts.push(node.textContent ?? "");
      else if (node.nodeType === 1) {
        const tag = node.tagName;
        if (/^(SCRIPT|STYLE|NOSCRIPT|SVG)$/.test(tag)) return;
        const block = /^(P|DIV|LI|UL|OL|H[1-6]|BR|SECTION|TR)$/.test(tag);
        if (block) parts.push("\n");
        if (tag === "LI") parts.push("• ");
        node.childNodes.forEach(walk);
        if (block) parts.push("\n");
      }
    };
    walk(element);
    return parts.join("").replace(/[ \t]+/g, " ").replace(/ ?\n ?/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function stripTags(html, doc) {
    const View = doc.defaultView ?? window;
    const inert = new View.DOMParser().parseFromString(html, "text/html");
    return blockText(inert.body);
  }
  function fromStructuredData(doc) {
    for (const script of doc.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const parsed = JSON.parse(script.textContent ?? "");
        const items = Array.isArray(parsed) ? parsed : [parsed, ...parsed?.["@graph"] ?? []];
        const posting = items.find((item) => item?.["@type"] === "JobPosting");
        if (!posting) continue;
        const organization = posting.hiringOrganization;
        const place = [posting.jobLocation].flat()[0];
        return {
          title: String(posting.title ?? ""),
          company: organization?.name ?? "",
          location: [place?.address?.addressLocality, place?.address?.addressRegion].filter(Boolean).join(", "),
          description: stripTags(String(posting.description ?? ""), doc)
        };
      } catch {
      }
    }
    return null;
  }
  function biggestBlock(doc) {
    let best = "";
    for (const element of doc.querySelectorAll("main, article, section, [role='main'], div")) {
      if (element.querySelectorAll("input, select, textarea").length > 3) continue;
      const text = blockText(element);
      const links = [...element.querySelectorAll("a")].reduce((total, link) => total + (link.textContent?.length ?? 0), 0);
      if (text.length > best.length && text.length < 3e4 && links < text.length * 0.3 && /experience|responsibilit|qualificat|requirement|skills/i.test(text)) best = text;
    }
    return best;
  }
  function readJob(doc, url) {
    const hostname = new URL(url).hostname;
    const site = SITES.find((entry) => entry.hosts.test(hostname));
    const structured = fromStructuredData(doc);
    const title = structured?.title || site && read(doc, site.title) || read(doc, "h1") || read(doc, 'meta[property="og:title"]');
    const description = structured?.description || site && read(doc, site.description) || biggestBlock(doc);
    if (!title || description.length < 200) return null;
    return {
      title: title.slice(0, 200),
      company: (structured?.company || site && read(doc, site.company) || read(doc, 'meta[property="og:site_name"]')).slice(0, 200),
      location: (structured?.location || site && read(doc, site.location) || "").slice(0, 200),
      description: description.slice(0, 4e4),
      url
    };
  }
  function isLinkedinProfile(url) {
    if (!URL.canParse(url)) return false;
    const { hostname, pathname } = new URL(url);
    return /(^|\.)linkedin\.com$/.test(hostname) && /^\/in\/[^/]+/.test(pathname);
  }
  const clean = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  const NOISE = /^(show all\b.*|…?\s*see more|see less|show more|show less|show credential|·.*|\d+ endorsements?|endorsed by .*|\d+ (experiences?|educations?) (at|across) .*|passed linkedin skill assessment)$/i;
  function visibleLines(root) {
    const spans = [...root.querySelectorAll('span[aria-hidden="true"]')].map((span) => clean(span.textContent));
    const raw = spans.some(Boolean) ? spans : (root.textContent ?? "").split("\n").map(clean);
    const lines = [];
    for (const line of raw) {
      if (!line || NOISE.test(line) || lines.at(-1) === line) continue;
      lines.push(line);
    }
    return lines;
  }
  function part(doc, id) {
    const section = doc.getElementById(id)?.closest("section") ?? doc.querySelector(`section[data-section="${id}"]`);
    if (!section) return [];
    const lines = visibleLines(section);
    return lines[0]?.toLowerCase() === id ? lines.slice(1) : lines;
  }
  function readLinkedinProfile(doc, url) {
    const main = doc.querySelector("main") ?? doc.body;
    const name = clean(main.querySelector("h1")?.textContent);
    let headline = clean(main.querySelector(".text-body-medium")?.textContent);
    if (!headline && name) {
      const top = main.querySelector("h1")?.closest("section");
      const lines = top ? (top.textContent ?? "").split("\n").map(clean).filter(Boolean) : [];
      headline = lines.slice(lines.indexOf(name) + 1).find((line) => line.length > 10 && !/^(he|she|they)\b|\b(1st|2nd|3rd)\b|contact info|connections|followers/i.test(line)) ?? "";
    }
    const address = URL.canParse(url) ? `linkedin.com${new URL(url).pathname.match(/^\/in\/[^/]+/)?.[0] ?? ""}` : "";
    return {
      headline: headline.slice(0, 400),
      about: part(doc, "about").join("\n").slice(0, 6e3),
      experience: part(doc, "experience").join("\n").slice(0, 2e4),
      // skill names are short, anything long is a description that slipped in
      skills: [...new Set(part(doc, "skills").filter((line) => line.length <= 50))].slice(0, 100),
      url: address
    };
  }
  function readPage() {
    return { url: location.href, job: readJob(document, location.href), linkedinProfile: isLinkedinProfile(location.href) };
  }
  if (!window.__resumefitLoaded) {
    window.__resumefitLoaded = true;
    chrome.runtime.onMessage.addListener((request, _sender, respond) => {
      if (request.type === "read-page") {
        respond(readPage());
      } else if (request.type === "read-linkedin") {
        respond(readLinkedinProfile(document, location.href));
      } else if (request.type === "selection") {
        respond(String(getSelection() ?? ""));
      }
      return false;
    });
  }
})();
