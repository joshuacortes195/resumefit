(function() {
  "use strict";
  const greenhouse = {
    id: "greenhouse",
    name: "Greenhouse",
    hosts: /(^|\.)greenhouse\.io$/,
    hints: [
      { selector: "#first_name", key: "firstName" },
      { selector: "#last_name", key: "lastName" },
      { selector: "#email", key: "email" },
      { selector: "#phone", key: "phone" },
      { selector: "#candidate-location, #job_application_location", key: "location" },
      { selector: 'input[type="file"]#resume, [data-field="resume"] input[type="file"], #resume_fieldset input[type="file"]', key: "resume" },
      { selector: 'input[type="file"]#cover_letter, [data-field="cover_letter"] input[type="file"]', key: "coverLetter" },
      { selector: "#job_application_gender, #gender", key: "eeoGender" },
      { selector: "#hispanic_ethnicity", key: "eeoHispanic" },
      { selector: "#job_application_race, #race", key: "eeoRace" },
      { selector: "#job_application_veteran_status, #veteran_status", key: "eeoVeteran" },
      { selector: "#job_application_disability_status, #disability_status", key: "eeoDisability" }
    ]
  };
  const lever = {
    id: "lever",
    name: "Lever",
    hosts: /(^|\.)lever\.co$/,
    hints: [
      { selector: 'input[name="name"]', key: "fullName" },
      { selector: 'input[name="email"]', key: "email" },
      { selector: 'input[name="phone"]', key: "phone" },
      { selector: 'input[name="location"]', key: "location" },
      { selector: 'input[name="org"]', key: "currentCompany" },
      { selector: 'input[name="urls[LinkedIn]"]', key: "linkedin" },
      { selector: 'input[name="urls[GitHub]"]', key: "github" },
      { selector: 'input[name="urls[Portfolio]"], input[name="urls[Other]"]', key: "website" },
      { selector: 'input[type="file"][name="resume"]', key: "resume" },
      { selector: 'select[name="eeo[gender]"]', key: "eeoGender" },
      { selector: 'select[name="eeo[race]"]', key: "eeoRace" },
      { selector: 'select[name="eeo[veteran]"]', key: "eeoVeteran" },
      { selector: 'select[name="eeo[disability]"]', key: "eeoDisability" }
    ]
  };
  const ashby = {
    id: "ashby",
    name: "Ashby",
    hosts: /(^|\.)ashbyhq\.com$/,
    hints: [
      { selector: 'input[name="_systemfield_name"]', key: "fullName" },
      { selector: 'input[name="_systemfield_email"]', key: "email" },
      { selector: 'input[name="_systemfield_phone"], input[type="tel"]', key: "phone" },
      { selector: 'input[name="_systemfield_location"]', key: "location" },
      { selector: 'input[type="file"]#_systemfield_resume, input[type="file"][name="_systemfield_resume"]', key: "resume" }
    ]
  };
  const workable = {
    id: "workable",
    name: "Workable",
    hosts: /(^|\.)workable\.com$/,
    hints: [
      { selector: 'input[name="firstname"]', key: "firstName" },
      { selector: 'input[name="lastname"]', key: "lastName" },
      { selector: 'input[name="email"]', key: "email" },
      { selector: 'input[name="phone"]', key: "phone" },
      { selector: 'input[name="address"]', key: "location" },
      { selector: 'input[type="file"][data-ui="resume"], [data-ui="resume"] input[type="file"]', key: "resume" }
    ]
  };
  const workday = {
    id: "workday",
    name: "Workday",
    hosts: /(^|\.)myworkdayjobs\.com$|(^|\.)workday\.com$/,
    multiPage: true,
    hints: [
      { selector: '[data-automation-id="legalNameSection_firstName"], [data-automation-id="firstName"]', key: "firstName" },
      { selector: '[data-automation-id="legalNameSection_lastName"], [data-automation-id="lastName"]', key: "lastName" },
      { selector: '[data-automation-id="email"]', key: "email" },
      { selector: '[data-automation-id="phone-number"], [data-automation-id="phoneNumber"]', key: "phone" },
      { selector: '[data-automation-id="addressSection_city"]', key: "city" },
      { selector: '[data-automation-id="addressSection_postalCode"]', key: "zip" },
      { selector: '[data-automation-id="addressSection_countryRegion"]', key: "state" },
      { selector: '[data-automation-id="countryDropdown"]', key: "country" },
      { selector: '[data-automation-id="file-upload-input-ref"]', key: "resume" },
      { selector: '[data-automation-id="sourceDropdown"], [data-automation-id="sourcePrompt"]', key: "howHeard" },
      { selector: '[data-automation-id="linkedinQuestion"]', key: "linkedin" }
    ]
  };
  const smartrecruiters = {
    id: "smartrecruiters",
    name: "SmartRecruiters",
    hosts: /(^|\.)smartrecruiters\.com$/,
    hints: [
      { selector: "#first-name-input, input[name='firstName']", key: "firstName" },
      { selector: "#last-name-input, input[name='lastName']", key: "lastName" },
      { selector: "#email-input, input[name='email']", key: "email" },
      { selector: "#linkedin-input", key: "linkedin" }
    ]
  };
  const icims = { id: "icims", name: "iCIMS", hosts: /(^|\.)icims\.com$/, hints: [] };
  const jobvite = { id: "jobvite", name: "Jobvite", hosts: /(^|\.)jobvite\.com$/, hints: [] };
  const bamboohr = { id: "bamboohr", name: "BambooHR", hosts: /(^|\.)bamboohr\.com$/, hints: [] };
  const taleo = { id: "taleo", name: "Taleo", hosts: /(^|\.)taleo\.net$|(^|\.)oraclecloud\.com$/, hints: [], multiPage: true };
  const generic = { id: "generic", name: "This site", hosts: /.*/, hints: [] };
  const ADAPTERS = [greenhouse, lever, ashby, workable, workday, smartrecruiters, icims, jobvite, bamboohr, taleo];
  function adapterFor(hostname) {
    return ADAPTERS.find((adapter) => adapter.hosts.test(hostname)) ?? generic;
  }
  const APPLY_TEXT = /^(apply|apply now|apply here|apply today|apply online|apply for (this|the) (job|role|position)|apply to (this|the) (job|role|position)|start (your )?application|i'?m interested)$/i;
  function findApplyLink(doc, url) {
    const frame = doc.querySelector('iframe[src*="greenhouse.io/embed/job_app"]');
    const candidates = [frame?.getAttribute("src"), ...[...doc.querySelectorAll("a[href]")].filter((link) => APPLY_TEXT.test((link.textContent ?? "").replace(/\s+/g, " ").trim())).map((link) => link.getAttribute("href"))];
    for (const href of candidates) {
      if (!href || href.startsWith("#")) continue;
      try {
        const target = new URL(href, url);
        if (target.protocol === "https:" && target.href.split("#")[0] !== url.split("#")[0]) return target.href;
      } catch {
      }
    }
    return null;
  }
  const NO_AUTOMATION = [/(^|\.)linkedin\.com$/, /(^|\.)indeed\.com$/];
  function fillBlocked(hostname) {
    return NO_AUTOMATION.some((host) => host.test(hostname));
  }
  const FIELD_PATTERNS = [
    // demographic questions first, so "gender" is never mistaken for something else
    ["eeoGender", /\bgender\b|\bsex\b/],
    // asked on its own on many forms, apart from race
    ["eeoHispanic", /hispanic|latino|latinx/],
    ["eeoRace", /\brace\b|ethnic/],
    ["eeoVeteran", /veteran/],
    ["eeoDisability", /disabilit/],
    ["pronouns", /\bpronouns?\b/],
    ["over18", /at least 18|18 years( of age)? or older|18 or older|over (the age of )?18|of legal age/],
    ["sponsorship", /sponsor|visa status|require.*(visa|h-?1b)/],
    ["workAuthorization", /authori[sz]ed to work|work authori[sz]ation|legally (authori[sz]ed|eligible|able|permitted)|eligible to work|right to work/],
    ["relocation", /relocat/],
    ["howHeard", /how did you (hear|find|learn)|where did you (hear|find)|referral source|source of (application|referral)/],
    ["resume", /resume|résumé|\bcv\b|curriculum vitae/],
    ["coverLetter", /cover letter/],
    ["linkedin", /linkedin/],
    ["github", /github/],
    ["website", /website|portfolio|personal (site|url|page)|\bblog\b|other (url|link)/],
    ["preferredName", /preferred (first )?name|nickname|what should we call you/],
    ["firstName", /first name|given name|forename|\bfname\b|firstname/],
    ["lastName", /last name|family name|surname|\blname\b|lastname/],
    ["fullName", /full name|legal name|your name|^name$|\bname\b/],
    ["email", /e-?mail/],
    ["phone", /phone|mobile|\btel\b|telephone|cell/],
    // school questions, the narrow ones first so "school" does not swallow them
    ["gpa", /\bgpa\b|grade point/],
    ["graduationYear", /graduation year|year of graduation/],
    ["graduationDate", /graduation (date|month)|(expected|anticipated) graduation|graduat(ed|ing) in|when (do|did|will) you graduate/],
    ["major", /\bmajor\b|field of study|area of study|discipline/],
    ["degree", /\bdegree\b|level of education|education level/],
    ["school", /\bschool\b|university|college|institution/],
    ["address", /street address|address line 1|address 1|mailing address|^address$/],
    ["zip", /\bzip\b|postal|postcode/],
    ["city", /\bcity\b|\btown\b/],
    ["state", /\bstate\b|province|\bregion\b/],
    ["country", /country/],
    ["location", /location|where are you (based|located)|current address|^address/],
    ["currentCompany", /current (company|employer)|present employer|^company$|^employer$|\borg(ani[sz]ation)?\b/],
    ["currentTitle", /current (title|role|position)|job title|^title$/],
    // only the total, never "years of experience with sql", which we cannot know
    ["yearsExperience", /(total )?years of (relevant |professional |work |total )?experience(?! (do you have )?(with|in|using|as)\b)|experience \(years\)/],
    ["salary", /salary|compensation|pay (expectation|range|rate)|desired pay|expected (ctc|pay)/],
    ["startDate", /start date|available to start|when can you start|availability|notice period/]
  ];
  const AUTOCOMPLETE = {
    "given-name": "firstName",
    "family-name": "lastName",
    name: "fullName",
    email: "email",
    tel: "phone",
    "tel-national": "phone",
    "address-level2": "city",
    "address-level1": "state",
    "postal-code": "zip",
    country: "country",
    "country-name": "country",
    organization: "currentCompany",
    "organization-title": "currentTitle",
    url: "website"
  };
  function normalize(text) {
    return text.toLowerCase().replace(/[_\-[\].]+/g, " ").replace(/[*:?()]/g, " ").replace(/\s+/g, " ").trim();
  }
  function matchKey(texts) {
    for (const raw of texts) {
      const text = normalize(raw);
      if (!text) continue;
      for (const [key, pattern] of FIELD_PATTERNS) if (pattern.test(text)) return key;
    }
    return null;
  }
  const DECLINE_PATTERN = /decline|prefer not|(don.t|do not) (wish|want)|not to (say|answer|disclose|identify)|choose not|rather not/i;
  const SKIP_TYPES = /* @__PURE__ */ new Set(["hidden", "submit", "button", "reset", "image", "password", "search", "range", "color"]);
  function textOf(element) {
    if (!element) return "";
    let source = element;
    if (element.querySelector("select, option, textarea, button")) {
      source = element.cloneNode(true);
      for (const inner of source.querySelectorAll("select, option, textarea, button, input")) inner.remove();
    }
    return (source.textContent ?? "").replace(/\s+/g, " ").trim();
  }
  function tidyLabel(label) {
    const star = label.indexOf("✱");
    return (star === -1 ? label : `${label.slice(0, star).trim()} ✱`).replace(/\s+/g, " ").trim();
  }
  const SHORT_ANSWERS = /* @__PURE__ */ new Set(["firstName", "lastName", "fullName", "preferredName", "email", "phone", "linkedin", "github", "website", "city", "state", "zip", "address", "location", "currentCompany", "currentTitle", "school", "degree", "major", "pronouns", "gpa"]);
  const ABOUT_SOMEONE_ELSE = /pronunciation|pronounce|\breferr|\brefer you|emergency|\breference|recruiter|manager/i;
  function keyFromWords(texts) {
    const key = matchKey(texts);
    return key && SHORT_ANSWERS.has(key) && readsLikeQuestion(texts[0] ?? "") ? null : key;
  }
  function readsLikeQuestion(label) {
    return label.length > 60 || label.includes("?") && label.split(/\s+/).length > 8 || ABOUT_SOMEONE_ELSE.test(label);
  }
  function labelFor(control, doc) {
    const aria = control.getAttribute("aria-label");
    if (aria?.trim()) return aria.trim();
    const labelledBy = control.getAttribute("aria-labelledby");
    if (labelledBy) {
      const text = labelledBy.split(/\s+/).map((id) => textOf(doc.getElementById(id))).join(" ").trim();
      if (text) return text;
    }
    if (control.id) {
      const label = [...doc.querySelectorAll("label")].find((entry) => entry.getAttribute("for") === control.id);
      if (label && textOf(label)) return textOf(label);
    }
    const wrapping = control.closest("label");
    if (wrapping && textOf(wrapping)) return textOf(wrapping);
    let node = control;
    for (let depth = 0; node && depth < 3; depth++, node = node.parentElement) {
      const previous = node.previousElementSibling;
      if (previous && /^(LABEL|SPAN|DIV|P)$/.test(previous.tagName) && !previous.querySelector("input, select, textarea") && textOf(previous) && textOf(previous).length < 200) return textOf(previous);
      if (previous) break;
    }
    const holder = control.closest('[class*="question"], [class*="field-entry"], [class*="fieldEntry"], [class*="form-group"]');
    const heading = holder?.querySelector('[class*="label"], [class*="title"], legend');
    if (heading && !heading.contains(control) && textOf(heading) && textOf(heading).length < 400) return textOf(heading);
    return control.getAttribute("placeholder")?.trim() ?? "";
  }
  function groupLabel(control, doc) {
    const fieldset = control.closest("fieldset");
    const legend = fieldset?.querySelector("legend");
    if (legend && textOf(legend)) return textOf(legend);
    const group = control.closest('[role="radiogroup"], [role="group"]');
    if (group) {
      const label = labelFor(group, doc);
      if (label) return label;
    }
    const name = control.getAttribute("name") ?? "";
    const total = name ? doc.querySelectorAll(`input[name="${CSS.escape(name)}"]`).length : 1;
    let parent = control.parentElement;
    for (let depth = 0; parent && depth < 8; depth++, parent = parent.parentElement) {
      if (name && parent.querySelectorAll(`input[name="${CSS.escape(name)}"]`).length < total) continue;
      const heading = [...parent.children].find((child) => !child.querySelector("input, select, textarea") && !/^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(child.tagName) && textOf(child));
      if (heading) return textOf(heading);
    }
    return "";
  }
  function isRequired(control, label) {
    return control.hasAttribute("required") || control.getAttribute("aria-required") === "true" || /[*\u2731]\s*$|\(required\)/i.test(label);
  }
  function findFields(doc, adapter) {
    const controls = [...doc.querySelectorAll("input, select, textarea")].filter((control) => {
      if (control instanceof HTMLInputElement && SKIP_TYPES.has(control.type)) return false;
      if (/captcha/i.test(`${control.getAttribute("name") ?? ""} ${control.id}`)) return false;
      if (control.getAttribute("role") === "combobox") return false;
      return !control.disabled && !control.closest('[aria-hidden="true"], [hidden]');
    });
    const fields2 = [];
    const groups = /* @__PURE__ */ new Map();
    for (const control of controls) {
      const type2 = control instanceof HTMLInputElement ? control.type : control.tagName.toLowerCase();
      const isChoice = type2 === "radio" || type2 === "checkbox";
      const name = control.getAttribute("name") ?? "";
      const grouped = isChoice && name !== "" && (type2 === "radio" || doc.querySelectorAll(`input[type="checkbox"][name="${CSS.escape(name)}"]`).length > 1);
      if (grouped) {
        const existing = groups.get(name);
        if (existing) {
          existing.elements.push(control);
          continue;
        }
      }
      if (type2 === "checkbox" && !grouped) continue;
      const label = tidyLabel(grouped ? groupLabel(control, doc) || labelFor(control, doc) : labelFor(control, doc));
      const hinted = adapter.hints.find((hint) => control.matches(hint.selector))?.key ?? null;
      const autocomplete = AUTOCOMPLETE[(control.getAttribute("autocomplete") ?? "").split(" ").at(-1) ?? ""] ?? null;
      let key = hinted ?? autocomplete ?? matchKey([label, name, control.id, control.getAttribute("placeholder") ?? ""]);
      if (!hinted && !autocomplete && key && SHORT_ANSWERS.has(key) && readsLikeQuestion(label)) key = null;
      const kind = type2 === "file" ? "file" : type2 === "radio" ? "radio" : type2 === "checkbox" ? "checkbox" : type2 === "select" || type2 === "select-one" ? "select" : type2 === "textarea" ? "textarea" : "text";
      if (kind === "file" && key !== "resume" && key !== "coverLetter") key = null;
      if (!key && (kind === "textarea" || kind === "text" && label.length > 25 && (label.includes("?") || label.length > 40))) key = "question";
      if (kind === "textarea" && !hinted) key = "question";
      const shown = kind === "file" && key && label.length < 12 ? key === "resume" ? "Resume" : "Cover letter" : label;
      const field = { id: `rf-${fields2.length}`, key, label: shown || name || control.id || "Unlabelled field", kind, required: isRequired(control, label), elements: [control] };
      for (const element of field.elements) element.setAttribute("data-resumefit-field", field.id);
      fields2.push(field);
      if (grouped) groups.set(name, field);
    }
    for (const field of groups.values()) for (const element of field.elements) element.setAttribute("data-resumefit-field", field.id);
    if (!fields2.some((field) => field.key === "resume")) {
      const loose = fields2.filter((field) => field.kind === "file" && field.key === null);
      if (loose.length === 1 && loose[0]) loose[0].key = "resume";
    }
    return fields2;
  }
  function looksLikeApplication(fields2) {
    const keys = new Set(fields2.map((field) => field.key));
    const hasName = keys.has("firstName") || keys.has("fullName") || keys.has("lastName");
    return hasName && keys.has("email") || keys.has("resume");
  }
  const MOVES_FORM = /\b(submit|apply|send|next|continue|finish|save|confirm|review|sign in|log in|create account)\b/i;
  function wordsOn$1(element) {
    return (element.textContent || element.getAttribute("value") || element.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
  }
  function wouldSubmit(element) {
    const tag = element.tagName;
    const type2 = (element.getAttribute("type") ?? "").toLowerCase();
    if (tag === "INPUT") return type2 === "submit" || type2 === "image" || type2 === "button" || type2 === "reset";
    const opensList = element.getAttribute("aria-haspopup") === "listbox";
    const answersYesNo = /^(yes|no)$/i.test(wordsOn$1(element)) && type2 !== "submit" && (type2 === "button" || element.closest("form") === null) && [...element.parentElement?.querySelectorAll(":scope > button") ?? []].length === 2;
    if (tag === "BUTTON" && answersYesNo) return false;
    if (tag === "BUTTON") return !opensList || type2 === "submit" || MOVES_FORM.test(wordsOn$1(element).replace(/\bselect one\b/i, ""));
    if (tag === "A") return true;
    return element.getAttribute("role") === "button" && MOVES_FORM.test(wordsOn$1(element));
  }
  function pressAnswer(element) {
    if (wouldSubmit(element)) return false;
    element.click();
    return true;
  }
  const EEO_KEYS = ["eeoGender", "eeoHispanic", "eeoRace", "eeoVeteran", "eeoDisability"];
  function setNativeValue(element, value) {
    const view = element.ownerDocument.defaultView ?? window;
    const prototype = element instanceof view.HTMLTextAreaElement ? view.HTMLTextAreaElement.prototype : element instanceof view.HTMLSelectElement ? view.HTMLSelectElement.prototype : view.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
    if (setter) setter.call(element, value);
    else element.value = value;
    element.dispatchEvent(new view.Event("input", { bubbles: true }));
    element.dispatchEvent(new view.Event("change", { bubbles: true }));
    element.dispatchEvent(new view.Event("blur", { bubbles: true }));
  }
  function matchOption(options, answer, key) {
    const wanted = normalize(answer);
    const texts = options.map((option) => normalize(option.text));
    const real = (index) => texts[index] !== "" && !/^(select|choose|please select|--)/.test(texts[index] ?? "");
    if (DECLINE_PATTERN.test(answer)) return { index: texts.findIndex((text, index) => real(index) && DECLINE_PATTERN.test(text)), sure: true };
    const exact = texts.findIndex((text, index) => real(index) && (text === wanted || normalize(options[index]?.value ?? "") === wanted));
    if (exact !== -1) return { index: exact, sure: true };
    if (wanted === "yes" || wanted === "no") return { index: texts.findIndex((text, index) => real(index) && new RegExp(`^${wanted}\\b`).test(text)), sure: true };
    if (key && EEO_KEYS.includes(key)) return { index: texts.findIndex((text, index) => real(index) && (text.startsWith(wanted) || wanted.startsWith(text))), sure: true };
    return { index: texts.findIndex((text, index) => real(index) && text.length > 1 && (text.includes(wanted) || wanted.includes(text))), sure: false };
  }
  function attachFile(input, file) {
    try {
      const view = input.ownerDocument.defaultView ?? window;
      const bytes = Uint8Array.from(atob(file.base64), (char) => char.charCodeAt(0));
      const transfer = new view.DataTransfer();
      transfer.items.add(new view.File([bytes], file.name, { type: file.type }));
      input.files = transfer.files;
      input.dispatchEvent(new view.Event("input", { bubbles: true }));
      input.dispatchEvent(new view.Event("change", { bubbles: true }));
      return (input.files?.length ?? 0) > 0;
    } catch {
      return false;
    }
  }
  function optionText(element) {
    const doc = element.ownerDocument;
    const byFor = element.id ? [...doc.querySelectorAll("label")].find((label) => label.getAttribute("for") === element.id) : null;
    return (byFor?.textContent ?? element.closest("label")?.textContent ?? element.getAttribute("aria-label") ?? element.getAttribute("value") ?? "").replace(/\s+/g, " ").trim();
  }
  function currentValue(field) {
    const [first] = field.elements;
    if (!first) return "";
    if (field.kind === "radio" || field.kind === "checkbox") {
      return field.elements.filter((element) => element.checked).map(optionText).join(", ");
    }
    if (field.kind === "file") return first.files?.[0]?.name ?? "";
    if (field.kind === "select") {
      const select = first;
      const chosen = select.options[select.selectedIndex];
      return chosen && chosen.value !== "" ? chosen.text.trim() : "";
    }
    return first.value;
  }
  function optionsOf(field) {
    const texts = field.kind === "select" ? [...field.elements[0].options].filter((option) => option.value !== "").map((option) => option.text) : field.kind === "radio" || field.kind === "checkbox" ? field.elements.map(optionText) : [];
    const clean2 = texts.map((text) => text.replace(/\s+/g, " ").trim().slice(0, 80)).filter(Boolean);
    return clean2.length > 0 ? clean2.slice(0, 15) : void 0;
  }
  const MONTH_NAMES = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  function monthValue(answer) {
    const [, name, year] = /^([a-z]+) (\d{4})$/i.exec(answer.trim()) ?? [];
    const month = name ? MONTH_NAMES.indexOf(name.toLowerCase()) + 1 : 0;
    return month > 0 && year ? `${year}-${String(month).padStart(2, "0")}` : null;
  }
  function fillField(field, answer, resume, coverLetter = null) {
    const [first] = field.elements;
    if (!first) return "skipped";
    const empty = field.required ? "missing" : "skipped";
    if (field.kind === "file") {
      const file = field.key === "resume" ? resume : field.key === "coverLetter" ? coverLetter : null;
      if (!file) return empty;
      return attachFile(first, file) ? "filled" : "missing";
    }
    if (!answer) return empty;
    if (field.kind === "select") {
      const select = first;
      const { index, sure } = matchOption([...select.options].map((option) => ({ text: option.text, value: option.value })), answer, field.key);
      if (index === -1) return empty;
      setNativeValue(select, select.options[index]?.value ?? "");
      return sure ? "filled" : "review";
    }
    if (field.kind === "radio" || field.kind === "checkbox") {
      const { index, sure } = matchOption(field.elements.map((element) => ({ text: optionText(element), value: element.getAttribute("value") ?? "" })), answer, field.key);
      const choice = field.elements[index];
      if (!choice) return empty;
      if (!choice.checked && !pressAnswer(choice)) return empty;
      return sure ? "filled" : "review";
    }
    const input = first;
    const type2 = input instanceof (input.ownerDocument.defaultView ?? window).HTMLInputElement ? input.type : "";
    if (type2 === "month" || type2 === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(answer)) {
      const month = type2 === "month" ? monthValue(answer) : null;
      if (!month) return empty;
      setNativeValue(input, month);
      return "filled";
    }
    setNativeValue(input, answer);
    return "filled";
  }
  function fillForm(fields2, values, resume, coverLetter = null) {
    return fields2.map((field) => {
      const answer = field.key && field.key !== "question" ? values[field.key] : void 0;
      const status = field.key === "question" ? field.required ? "missing" : "skipped" : fillField(field, answer, resume, coverLetter);
      const file = field.key === "coverLetter" ? coverLetter : resume;
      const put = field.kind === "file" ? file?.name ?? "" : answer ?? "";
      return { id: field.id, key: field.key, label: field.label, kind: field.kind, required: field.required, status, value: currentValue(field) || (status === "filled" || status === "review" ? put : ""), options: optionsOf(field) };
    });
  }
  const OUTLINES = { filled: "#15803d", review: "#ca8a04", missing: "#b91c1c", skipped: "" };
  function highlight(field, status) {
    for (const element of field.elements) {
      const target = field.kind === "radio" || field.kind === "checkbox" ? element.closest("label") ?? element : element;
      target.style.outline = OUTLINES[status] ? `2px solid ${OUTLINES[status]}` : "";
      target.style.outlineOffset = OUTLINES[status] ? "2px" : "";
      element.setAttribute("data-resumefit-status", status);
    }
  }
  const PLACEHOLDER = /^(select( one| an option)?(\.\.\.)?|choose( one)?|please select|--+)?$/i;
  async function until(check, timeoutMs) {
    const started = Date.now();
    for (; ; ) {
      const found = check();
      if (found) return found;
      if (Date.now() - started > timeoutMs) return null;
      await new Promise((done) => setTimeout(done, 60));
    }
  }
  const words = (element) => (element?.textContent ?? "").replace(/\s+/g, " ").trim();
  const usable = (element) => !element.disabled && !element.closest('[aria-hidden="true"], [hidden]');
  function questionOf(element, doc) {
    return labelFor(element, doc).replace(/\b(select one|required|optional)\b/gi, " ").replace(/\(\s*\)/g, " ").replace(/\s+/g, " ").trim();
  }
  function pick(options, answer, key) {
    const { index, sure } = matchOption(options.map((option) => ({ text: words(option), value: option.getAttribute("data-value") ?? "" })), answer, key);
    const choice = options[index];
    return choice ? { choice, sure } : null;
  }
  function findDropdowns(doc) {
    return [...doc.querySelectorAll('button[aria-haspopup="listbox"]')].filter(usable);
  }
  async function chooseFromButton(button, answer, key, doc) {
    if (!pressAnswer(button)) return null;
    const options = await until(() => {
      const found = [...doc.querySelectorAll('[role="listbox"] [role="option"], [role="option"]')];
      return found.length > 0 ? found : null;
    }, 1500);
    const match = options ? pick(options, answer, key) : null;
    if (match) {
      const picked = words(match.choice);
      match.choice.click();
      return { words: picked, sure: match.sure };
    }
    const view = doc.defaultView ?? window;
    (doc.activeElement ?? button).dispatchEvent(new view.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    await new Promise((done) => setTimeout(done, 80));
    if (options?.some((option) => option.isConnected)) button.click();
    return null;
  }
  function buttonWidget(button, doc) {
    const label = questionOf(button, doc);
    return {
      element: button,
      label,
      required: button.getAttribute("aria-required") === "true" || /required|\*\s*$/i.test(button.getAttribute("aria-label") ?? "") || /\*\s*$/.test(label),
      shown: () => PLACEHOLDER.test(words(button)) ? "" : words(button),
      choose: (answer, key) => chooseFromButton(button, answer, key, doc)
    };
  }
  function findComboboxes(doc) {
    return [...doc.querySelectorAll('input[role="combobox"]')].filter(usable);
  }
  function shellOf(input) {
    let node = input;
    for (let depth = 0; depth < 6 && node.parentElement; depth++) {
      node = node.parentElement;
      if (/select|combobox|autocomplete|dropdown/i.test(node.className) && node.querySelector('[class*="control"], [class*="indicator"], [role="option"], [role="listbox"]')) return node;
    }
    return input.parentElement ?? input;
  }
  function listOf(input, doc) {
    const listId = input.getAttribute("aria-controls") ?? input.getAttribute("aria-owns");
    const list = listId ? doc.getElementById(listId) : null;
    const inList = list ? [...list.querySelectorAll('[role="option"]')] : [];
    if (inList.length > 0) return inList;
    const near = [...shellOf(input).querySelectorAll('[role="option"]')];
    return near.length > 0 ? near : [...doc.querySelectorAll('[role="listbox"] [role="option"]')];
  }
  function type(input, text) {
    const view = input.ownerDocument.defaultView ?? window;
    const setter = Object.getOwnPropertyDescriptor(view.HTMLInputElement.prototype, "value")?.set;
    if (setter) setter.call(input, text);
    else input.value = text;
    input.dispatchEvent(new view.Event("input", { bubbles: true }));
  }
  async function chooseFromSearch(input, answer, key, doc) {
    const view = doc.defaultView ?? window;
    const press = (target, event) => target.dispatchEvent(new view.MouseEvent(event, { bubbles: true, cancelable: true }));
    input.focus();
    press(shellOf(input).querySelector('[class*="control"]') ?? input, "mousedown");
    let options = await until(() => listOf(input, doc).length > 0 ? listOf(input, doc) : null, 700) ?? [];
    let match = pick(options, answer, key);
    if (!match) {
      type(input, answer);
      options = await until(() => listOf(input, doc).some((option) => !/^(loading|no (options|results))/i.test(words(option))) ? listOf(input, doc) : null, 2500) ?? [];
      match = pick(options, answer, key);
      const real = options.filter((option) => !/^(loading|no (options|results))/i.test(words(option)));
      if (!match && (key === "location" || key === "city") && real[0]) match = { choice: real[0], sure: false };
    }
    if (match) {
      const picked = words(match.choice);
      press(match.choice, "mousedown");
      if (pressAnswer(match.choice)) return { words: picked, sure: match.sure };
    }
    if (input.value) type(input, "");
    input.dispatchEvent(new view.KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
    input.blur();
    return null;
  }
  function searchWidget(input, doc) {
    const label = questionOf(input, doc);
    const shell = shellOf(input);
    const chosen = () => words(shell.querySelector('[class*="single-value"], [class*="singleValue"], [class*="selected-value"]')) || input.value.trim();
    return {
      element: input,
      label,
      required: input.getAttribute("aria-required") === "true" || input.required || /[*✱]\s*$/.test(label),
      shown: chosen,
      choose: (answer, key) => chooseFromSearch(input, answer, key, doc)
    };
  }
  function findYesNo(doc) {
    const groups = /* @__PURE__ */ new Set();
    for (const button of doc.querySelectorAll("button")) {
      const parent = button.parentElement;
      if (!parent || !usable(button) || !/^(yes|no)$/i.test(words(button)) || wouldSubmit(button)) continue;
      const said = [...parent.querySelectorAll(":scope > button")].map((entry) => words(entry).toLowerCase()).sort();
      if (said.length === 2 && said[0] === "no" && said[1] === "yes") groups.add(parent);
    }
    return [...groups];
  }
  function yesNoWidget(group, doc) {
    const buttons = [...group.querySelectorAll(":scope > button")];
    const label = questionOf(group, doc);
    const on = (button) => button.getAttribute("aria-pressed") === "true" || button.getAttribute("aria-checked") === "true" || /\b(active|selected|checked)\b/i.test(button.className);
    return {
      element: group,
      label,
      // the form marks these as required on the question, in a class or with a star
      required: /[*✱]\s*$/.test(label) || group.parentElement?.querySelector('[class*="required"]') != null,
      options: ["Yes", "No"],
      shown: () => words(buttons.find(on)),
      choose: async (answer) => {
        const wanted = /^\s*yes\b/i.test(answer) ? "yes" : /^\s*no\b/i.test(answer) ? "no" : null;
        const button = buttons.find((entry) => words(entry).toLowerCase() === wanted);
        return button && pressAnswer(button) ? { words: words(button), sure: true } : null;
      }
    };
  }
  function findWidgets(doc) {
    const found = [...findDropdowns(doc).map((button) => buttonWidget(button, doc)), ...findComboboxes(doc).map((input) => searchWidget(input, doc)), ...findYesNo(doc).map((group) => yesNoWidget(group, doc))];
    return found.sort((a, b) => a.element.compareDocumentPosition(b.element) & 4 ? -1 : 1);
  }
  const colorOf = (status) => status === "filled" ? "#15803d" : status === "review" ? "#ca8a04" : status === "missing" ? "#b91c1c" : "";
  function mark(widget, status) {
    widget.element.setAttribute("data-resumefit-status", status);
    const box = widget.element instanceof HTMLInputElement ? shellOf(widget.element) : widget.element;
    box.style.outline = colorOf(status) ? `2px solid ${colorOf(status)}` : "";
    box.style.outlineOffset = colorOf(status) ? "2px" : "";
  }
  async function setDropdown(doc, id, value, key, status) {
    const widget = findWidgets(doc).find((entry) => entry.element.getAttribute("data-resumefit-field") === id);
    if (!widget) return null;
    const picked = await widget.choose(value, key ?? "question");
    const result = picked ? status : widget.required ? "missing" : "skipped";
    mark(widget, result);
    return { id, key, label: widget.label || "Dropdown", kind: "select", required: widget.required, status: result, value: picked?.words ?? "", ...widget.options ? { options: widget.options } : {} };
  }
  async function fillDropdowns(doc, values, onlyNew) {
    const reports = [];
    for (const [index, widget] of findWidgets(doc).entries()) {
      const element = widget.element;
      const id = element.getAttribute("data-resumefit-field") ?? `rf-d-${index}`;
      element.setAttribute("data-resumefit-field", id);
      const key = keyFromWords([widget.label, element.id, element.getAttribute("name") ?? ""]);
      let status = element.getAttribute("data-resumefit-status") ?? null;
      let picked = "";
      const skip = onlyNew && status !== null;
      if (!skip) {
        const answer = key && key !== "question" ? key === "city" && values.location ? values.location : values[key] : void 0;
        const empty = widget.shown() === "";
        if (answer && key && empty) {
          const choice = await widget.choose(answer, key);
          picked = choice?.words ?? "";
          status = choice ? choice.sure ? "filled" : "review" : widget.required ? "missing" : "skipped";
        } else status = !empty ? "filled" : widget.required ? "missing" : "skipped";
        mark(widget, status);
      }
      reports.push({ id, key, label: widget.label || "Dropdown", kind: "select", required: widget.required, status: status ?? "skipped", value: widget.shown() || picked, fresh: !skip, ...widget.options ? { options: widget.options } : {} });
    }
    return reports;
  }
  const SITES = [
    {
      hosts: /linkedin\.com$/,
      title: ".job-details-jobs-unified-top-card__job-title, .top-card-layout__title, .jobs-unified-top-card__job-title",
      company: ".job-details-jobs-unified-top-card__company-name, .topcard__org-name-link, .jobs-unified-top-card__company-name",
      location: ".job-details-jobs-unified-top-card__primary-description-container span, .topcard__flavor--bullet",
      description: "#job-details, .jobs-description__content, .show-more-less-html__markup"
    },
    {
      hosts: /indeed\.com$/,
      title: '[data-testid="jobsearch-JobInfoHeader-title"], .jobsearch-JobInfoHeader-title',
      company: '[data-testid="inlineHeader-companyName"], [data-company-name="true"]',
      location: '[data-testid="inlineHeader-companyLocation"], [data-testid="job-location"]',
      description: "#jobDescriptionText"
    },
    {
      hosts: /glassdoor\.[a-z.]+$/,
      title: '[data-test="job-title"], h1[id^="jd-job-title"]',
      company: '[data-test="employer-name"], [class*="EmployerProfile_employerName"]',
      location: '[data-test="location"]',
      description: '[class*="JobDetails_jobDescription"], .jobDescriptionContent'
    },
    { hosts: /greenhouse\.io$/, title: "h1.app-title, .job__title h1, h1", company: ".company-name, .job__header .company", location: ".location, .job__location", description: "#content, .job__description" },
    { hosts: /lever\.co$/, title: ".posting-headline h2", company: ".main-header-logo img", location: ".posting-categories .location", description: '[data-qa="job-description"], .section-wrapper.page-full-width' },
    { hosts: /ashbyhq\.com$/, title: "h1", company: 'meta[property="og:site_name"]', location: '[class*="_location"]', description: '[class*="_descriptionText"], #overview' }
  ];
  function read(doc, selector) {
    if (!selector) return "";
    const element = doc.querySelector(selector);
    if (!element) return "";
    const text = element.getAttribute("content") ?? element.getAttribute("alt") ?? blockText(element);
    return text.replace(/[ \t]+/g, " ").trim();
  }
  function blockText(element) {
    const parts = [];
    const walk = (node) => {
      if (node.nodeType === 3) parts.push(node.textContent ?? "");
      else if (node.nodeType === 1) {
        const tag = node.tagName;
        if (/^(SCRIPT|STYLE|NOSCRIPT|SVG)$/.test(tag)) return;
        const block = /^(P|DIV|LI|UL|OL|H[1-6]|BR|SECTION|TR)$/.test(tag);
        if (block) parts.push("\n");
        if (tag === "LI") parts.push("• ");
        node.childNodes.forEach(walk);
        if (block) parts.push("\n");
      }
    };
    walk(element);
    return parts.join("").replace(/[ \t]+/g, " ").replace(/ ?\n ?/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  }
  function stripTags(html, doc) {
    const View = doc.defaultView ?? window;
    const inert = new View.DOMParser().parseFromString(html, "text/html");
    return blockText(inert.body);
  }
  function fromStructuredData(doc) {
    for (const script of doc.querySelectorAll('script[type="application/ld+json"]')) {
      try {
        const parsed = JSON.parse(script.textContent ?? "");
        const items = Array.isArray(parsed) ? parsed : [parsed, ...parsed?.["@graph"] ?? []];
        const posting = items.find((item) => item?.["@type"] === "JobPosting");
        if (!posting) continue;
        const organization = posting.hiringOrganization;
        const place = [posting.jobLocation].flat()[0];
        return {
          title: String(posting.title ?? ""),
          company: organization?.name ?? "",
          location: [place?.address?.addressLocality, place?.address?.addressRegion].filter(Boolean).join(", "),
          description: stripTags(String(posting.description ?? ""), doc)
        };
      } catch {
      }
    }
    return null;
  }
  function biggestBlock(doc) {
    let best = "";
    for (const element of doc.querySelectorAll("main, article, section, [role='main'], div")) {
      if (element.querySelectorAll("input, select, textarea").length > 3) continue;
      const text = blockText(element);
      const links = [...element.querySelectorAll("a")].reduce((total, link) => total + (link.textContent?.length ?? 0), 0);
      if (text.length > best.length && text.length < 3e4 && links < text.length * 0.3 && /experience|responsibilit|qualificat|requirement|skills/i.test(text)) best = text;
    }
    return best;
  }
  function readJob(doc, url) {
    const hostname = new URL(url).hostname;
    const site = SITES.find((entry) => entry.hosts.test(hostname));
    const structured = fromStructuredData(doc);
    const title = structured?.title || site && read(doc, site.title) || read(doc, "h1") || read(doc, 'meta[property="og:title"]');
    const description = structured?.description || site && read(doc, site.description) || biggestBlock(doc);
    if (!title || description.length < 200) return null;
    return {
      title: title.slice(0, 200),
      company: (structured?.company || site && read(doc, site.company) || read(doc, 'meta[property="og:site_name"]')).slice(0, 200),
      location: (structured?.location || site && read(doc, site.location) || "").slice(0, 200),
      description: description.slice(0, 4e4),
      url
    };
  }
  function showing(element) {
    const view = element.ownerDocument.defaultView;
    for (let node = element; node; node = node.parentElement) {
      const style = view?.getComputedStyle(node);
      if (node.hasAttribute("hidden") || style?.display === "none" || style?.visibility === "hidden" || style?.opacity === "0") return false;
    }
    return true;
  }
  function captchaKind(doc) {
    const puzzle = [...doc.querySelectorAll('iframe[src*="recaptcha"][src*="bframe"], iframe[src*="hcaptcha"][src*="challenge"]')].some((frame) => showing(frame) && frame.offsetHeight !== 0);
    if (puzzle || doc.querySelector("#px-captcha, .cf-turnstile, iframe[src*='turnstile']")) return "challenge";
    const anchors = [...doc.querySelectorAll('iframe[src*="recaptcha"][src*="anchor"]')];
    const widgets = [...doc.querySelectorAll(".g-recaptcha")];
    const google = anchors.length > 0 || widgets.length > 0 || doc.querySelector(".grecaptcha-badge") !== null;
    const googleHidden = anchors.every((frame) => /[?&]size=invisible/.test(frame.getAttribute("src") ?? "")) && widgets.every((widget) => widget.getAttribute("data-size") === "invisible");
    const boxes = [...doc.querySelectorAll(".h-captcha")];
    const other = boxes.length > 0 || doc.querySelector('iframe[src*="hcaptcha"]') !== null;
    const otherHidden = boxes.length > 0 && boxes.every((box) => box.getAttribute("data-size") === "invisible");
    if (google && !googleHidden || other && !otherHidden) return "challenge";
    if (google || other) return "background";
    return doc.querySelector("[data-sitekey]") ? "challenge" : "none";
  }
  function hasCaptcha(doc) {
    return captchaKind(doc) === "challenge";
  }
  function visibleText(element, limit) {
    const parts = [];
    let length = 0;
    const walk = (node) => {
      if (length > limit) return;
      if (node.nodeType === 3) {
        parts.push(node.textContent ?? "");
        length += node.textContent?.length ?? 0;
      } else if (node.nodeType === 1) {
        const child = node;
        if (/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|SVG)$/i.test(child.tagName) || child.hidden || child.getAttribute("aria-hidden") === "true") return;
        if (typeof child.checkVisibility === "function" && !child.checkVisibility()) return;
        child.childNodes.forEach(walk);
      }
    };
    walk(element);
    return parts.join(" ").replace(/\s+/g, " ");
  }
  function looksConfirmed(doc) {
    const main = doc.querySelector("main, [role='main'], body");
    const text = main ? visibleText(main, 6e3).slice(0, 6e3) : "";
    const THANKS = /thank(s| you) for (applying|your (application|interest in (applying|joining)))|application (has been |was )?(successfully |now )?(submitted|received|sent)|(successfully|already) (applied|submitted)|we('ve| have)? (got|received) your application|your application is (complete|in)\b/i;
    return text.split(new RegExp("(?<=[.!?])\\s+|\\n")).some((line) => THANKS.test(line) && !/\b(once|when|after|if|until|before|as soon as)\b/i.test(line.slice(0, line.search(THANKS))));
  }
  function isLinkedinProfile(url) {
    if (!URL.canParse(url)) return false;
    const { hostname, pathname } = new URL(url);
    return /(^|\.)linkedin\.com$/.test(hostname) && /^\/in\/[^/]+/.test(pathname);
  }
  const clean = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  const NOISE = /^(show all\b.*|…?\s*see more|see less|show more|show less|show credential|·.*|\d+ endorsements?|endorsed by .*|\d+ (experiences?|educations?) (at|across) .*|passed linkedin skill assessment)$/i;
  function visibleLines(root) {
    const spans = [...root.querySelectorAll('span[aria-hidden="true"]')].map((span) => clean(span.textContent));
    const raw = spans.some(Boolean) ? spans : (root.textContent ?? "").split("\n").map(clean);
    const lines = [];
    for (const line of raw) {
      if (!line || NOISE.test(line) || lines.at(-1) === line) continue;
      lines.push(line);
    }
    return lines;
  }
  function part(doc, id) {
    const section = doc.getElementById(id)?.closest("section") ?? doc.querySelector(`section[data-section="${id}"]`);
    if (!section) return [];
    const lines = visibleLines(section);
    return lines[0]?.toLowerCase() === id ? lines.slice(1) : lines;
  }
  function readLinkedinProfile(doc, url) {
    const main = doc.querySelector("main") ?? doc.body;
    const name = clean(main.querySelector("h1")?.textContent);
    let headline = clean(main.querySelector(".text-body-medium")?.textContent);
    if (!headline && name) {
      const top = main.querySelector("h1")?.closest("section");
      const lines = top ? (top.textContent ?? "").split("\n").map(clean).filter(Boolean) : [];
      headline = lines.slice(lines.indexOf(name) + 1).find((line) => line.length > 10 && !/^(he|she|they)\b|\b(1st|2nd|3rd)\b|contact info|connections|followers/i.test(line)) ?? "";
    }
    const address = URL.canParse(url) ? `linkedin.com${new URL(url).pathname.match(/^\/in\/[^/]+/)?.[0] ?? ""}` : "";
    return {
      headline: headline.slice(0, 400),
      about: part(doc, "about").join("\n").slice(0, 6e3),
      experience: part(doc, "experience").join("\n").slice(0, 2e4),
      // skill names are short, anything long is a description that slipped in
      skills: [...new Set(part(doc, "skills").filter((line) => line.length <= 50))].slice(0, 100),
      url: address
    };
  }
  const SENDS = /^(submit|submit( my| your| the)? application|apply|apply now|send application|submit and apply)$/i;
  function wordsOn(element) {
    return (element.textContent || element.getAttribute("value") || element.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
  }
  function unusable(element) {
    return element.closest("[hidden], [aria-hidden='true']") !== null || element.hasAttribute("disabled") || element.getAttribute("aria-disabled") === "true";
  }
  function findSubmit(doc) {
    const form = doc.querySelector("[data-resumefit-field]")?.closest("form") ?? null;
    const within = form ?? doc;
    const found = [...within.querySelectorAll('button, input[type="submit"]')].filter((button) => !unusable(button) && SENDS.test(wordsOn(button)));
    return found.length === 1 ? found[0] ?? null : null;
  }
  function pressSubmit(doc, hostname) {
    if (fillBlocked(hostname)) return { pressed: false, reason: "This site does not allow tools to send applications." };
    if (hasCaptcha(doc)) return { pressed: false, reason: "The form has a captcha, which only you can do." };
    const button = findSubmit(doc);
    if (!button) return { pressed: false, reason: "We could not tell which button sends this form." };
    button.click();
    return { pressed: true };
  }
  let fields = [];
  function report(field, status) {
    return { id: field.id, key: field.key, label: field.label, kind: field.kind, required: field.required, status, value: currentValue(field), options: optionsOf(field) };
  }
  const statusOf = (field) => field.elements[0]?.getAttribute("data-resumefit-status") ?? "skipped";
  function readPage() {
    const adapter = adapterFor(location.hostname);
    const blocked = fillBlocked(location.hostname);
    fields = blocked ? [] : findFields(document, adapter);
    const hasForm = looksLikeApplication(fields);
    return {
      url: location.href,
      job: readJob(document, location.href),
      linkedinProfile: isLinkedinProfile(location.href),
      ats: adapter.id === "generic" ? null : { id: adapter.id, name: adapter.name },
      hasForm,
      multiPage: adapter.multiPage === true,
      fields: hasForm ? fields.map((field) => report(field, statusOf(field))) : [],
      captcha: hasCaptcha(document),
      confirmed: looksConfirmed(document),
      fillBlocked: blocked
    };
  }
  if (!window.__resumefitLoaded) {
    window.__resumefitLoaded = true;
    chrome.runtime.onMessage.addListener((request, _sender, respond) => {
      if (request.type === "read-page") {
        respond(readPage());
      } else if (request.type === "autofill") {
        if (fillBlocked(location.hostname)) {
          respond([]);
          return false;
        }
        fields = findFields(document, adapterFor(location.hostname));
        const kept = request.onlyNew ? fields.filter((field) => field.elements[0]?.hasAttribute("data-resumefit-status")) : [];
        const results = fillForm(fields.filter((field) => !kept.includes(field)), request.values, request.resume, request.coverLetter);
        for (const result of results) {
          const field = fields.find((entry) => entry.id === result.id);
          if (field) highlight(field, result.status);
        }
        const before = kept.map((field) => ({ ...report(field, statusOf(field)), fresh: false }));
        void fillDropdowns(document, request.values, request.onlyNew === true).catch(() => []).then((dropdowns) => respond([...before, ...results, ...dropdowns]));
        return true;
      } else if (request.type === "set-field") {
        const field = fields.find((entry) => entry.id === request.id);
        if (field) {
          const result = fillField({ ...field, key: request.key ?? field.key }, request.value, null);
          const done = result === "filled" || result === "review";
          const status = done ? request.status : field.required ? "missing" : "skipped";
          highlight(field, status);
          respond({ ...report(field, status), value: currentValue(field) || (done ? request.value : "") });
        } else {
          void setDropdown(document, request.id, request.value, request.key ?? null, request.status).catch(() => null).then(respond);
          return true;
        }
      } else if (request.type === "focus-field") {
        const element = fields.find((entry) => entry.id === request.id)?.elements[0] ?? document.querySelector(`[data-resumefit-field="${CSS.escape(request.id)}"]`);
        element?.scrollIntoView({ behavior: "smooth", block: "center" });
        element?.focus({ preventScroll: true });
        respond(true);
      } else if (request.type === "find-apply") {
        respond(findApplyLink(document, location.href));
      } else if (request.type === "submit") {
        respond(pressSubmit(document, location.hostname));
      } else if (request.type === "read-linkedin") {
        respond(readLinkedinProfile(document, location.href));
      } else if (request.type === "selection") {
        respond(String(getSelection() ?? ""));
      }
      return false;
    });
  }
})();
